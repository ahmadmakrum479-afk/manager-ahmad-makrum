package com.cricketmanager.app

import com.cricketmanager.app.data.local.BallEventEntity
import com.cricketmanager.app.data.local.Converters
import com.cricketmanager.app.data.local.ExtraType
import com.cricketmanager.app.data.local.MatchEntity
import com.cricketmanager.app.data.local.MatchStage
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.PitchType
import com.cricketmanager.app.data.local.PlayoffType
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.PlayerMatchStatEntity
import com.cricketmanager.app.data.local.PlayerRole
import com.cricketmanager.app.data.local.ScoringMode
import com.cricketmanager.app.data.local.TeamEntity
import com.cricketmanager.app.data.local.TieRule
import com.cricketmanager.app.data.local.TournamentEntity
import com.cricketmanager.app.data.local.TournamentFormat
import com.cricketmanager.app.data.local.UserRole
import com.cricketmanager.app.data.local.WicketType
import com.cricketmanager.app.domain.AuthSecurity
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.domain.TournamentBackupBundle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CricketModelUnitTest {

    @Test
    fun netRunRate_isCalculatedAccurately() {
        val nrr = CricketStatsEngine.calculateNetRunRate(
            runsFor = 120,
            ballsFaced = 60,
            runsAgainst = 100,
            ballsBowled = 60
        )
        assertEquals(2.0, nrr, 0.001)
        assertEquals("+2.000", CricketStatsEngine.formatNrr(nrr))
    }

    @Test
    fun test1_allOut8Wickets_nrrMatchesExactExpected() {
        val tournament = TournamentEntity(
            ownerUserId = 1L,
            name = "Test Cup",
            oversPerMatch = 8,
            tournamentCode = "CM0001",
            editorCode = "ED0001",
            viewerCode = "VW0001"
        )
        val teamA = TeamEntity(id = 1L, tournamentId = 1L, name = "Team Ka", shortCode = "KA")
        val teamB = TeamEntity(id = 2L, tournamentId = 1L, name = "Team Kha", shortCode = "KHA")
        val match = MatchEntity(
            id = 10L,
            tournamentId = 1L,
            stage = MatchStage.LEAGUE,
            teamAId = 1L,
            teamBId = 2L,
            teamAName = "Team Ka",
            teamBName = "Team Kha",
            oversLimit = 8,
            status = MatchStatus.COMPLETED,
            battingFirstTeamId = 1L,
            teamARuns = 40,
            teamAWickets = 8,
            teamABalls = 30, // 5.0 overs, but all out at 8 wickets -> 8.0 overs (48 balls)
            teamBRuns = 41,
            teamBWickets = 2,
            teamBBalls = 26  // 4.2 overs
        )
        val standings = CricketStatsEngine.computeTeamStandings(listOf(teamA, teamB), listOf(match), tournament, allOutWickets = 8)
        val ka = standings.first { it.id == 1L }
        val kha = standings.first { it.id == 2L }
        val kaNrr = CricketStatsEngine.calculateNetRunRate(ka.runsFor, ka.ballsFaced, ka.runsAgainst, ka.ballsBowled)
        val khaNrr = CricketStatsEngine.calculateNetRunRate(kha.runsFor, kha.ballsFaced, kha.runsAgainst, kha.ballsBowled)
        assertEquals("-4.462", CricketStatsEngine.formatNrr(kaNrr))
        assertEquals("+4.462", CricketStatsEngine.formatNrr(khaNrr))
    }

    @Test
    fun test2_blankOrZeroOvers_usesFullQuota() {
        assertEquals(48, CricketStatsEngine.effectiveInningsBalls(wickets = 3, balls = 0, maxOvers = 8, allOutWickets = 8))
    }

    @Test
    fun test3_playoffMatches_excludedFromPointsTableAndNrr() {
        val tournament = TournamentEntity(
            ownerUserId = 1L,
            name = "Test Cup",
            oversPerMatch = 8,
            tournamentCode = "CM0002",
            editorCode = "ED0002",
            viewerCode = "VW0002"
        )
        val t1 = TeamEntity(id = 1L, tournamentId = 1L, name = "A", shortCode = "A")
        val t2 = TeamEntity(id = 2L, tournamentId = 1L, name = "B", shortCode = "B")
        val leagueMatches = (1..3).map { idx ->
            MatchEntity(
                id = idx.toLong(),
                tournamentId = 1L,
                stage = MatchStage.LEAGUE,
                teamAId = 1L,
                teamBId = 2L,
                teamAName = "A",
                teamBName = "B",
                oversLimit = 8,
                status = MatchStatus.COMPLETED,
                teamARuns = 80,
                teamAWickets = 4,
                teamABalls = 48,
                teamBRuns = 70,
                teamBWickets = 6,
                teamBBalls = 48
            )
        }
        val playoffMatch = MatchEntity(
            id = 99L,
            tournamentId = 1L,
            stage = MatchStage.FINAL,
            teamAId = 1L,
            teamBId = 2L,
            teamAName = "A",
            teamBName = "B",
            oversLimit = 8,
            status = MatchStatus.COMPLETED,
            teamARuns = 50,
            teamAWickets = 8,
            teamABalls = 48,
            teamBRuns = 90,
            teamBWickets = 1,
            teamBBalls = 48
        )
        val standings = CricketStatsEngine.computeTeamStandings(listOf(t1, t2), leagueMatches + playoffMatch, tournament)
        val team1 = standings.first { it.id == 1L }
        val team2 = standings.first { it.id == 2L }
        assertEquals(3, team1.played)
        assertEquals(6, team1.points)
        assertEquals(3, team2.played)
        assertEquals(0, team2.points)
    }

    @Test
    fun test5_reEditingMatch_recalculatesHighestScoreAndBestBowling() {
        val p1 = PlayerEntity(id = 10L, tournamentId = 1L, teamId = 1L, name = "Player 1", highestScore = 99, bestBowlingWickets = 5, bestBowlingRuns = 5)
        val m1 = MatchEntity(id = 1L, tournamentId = 1L, teamAId = 1L, teamBId = 2L, teamAName = "A", teamBName = "B", status = MatchStatus.COMPLETED)
        val m2 = MatchEntity(id = 2L, tournamentId = 1L, teamAId = 1L, teamBId = 2L, teamAName = "A", teamBName = "B", status = MatchStatus.COMPLETED)

        val editedStatsMap = mapOf(
            1L to listOf(PlayerMatchStatEntity(tournamentId = 1L, matchId = 1L, teamId = 1L, playerId = 10L, playerName = "Player 1", innings = 1, didBat = true, runsScored = 25, didBowl = true, ballsBowled = 12, runsConceded = 18, wicketsTaken = 1)),
            2L to listOf(PlayerMatchStatEntity(tournamentId = 1L, matchId = 2L, teamId = 1L, playerId = 10L, playerName = "Player 1", innings = 1, didBat = true, runsScored = 42, didBowl = true, ballsBowled = 12, runsConceded = 12, wicketsTaken = 2))
        )
        val rebuilt = CricketStatsEngine.aggregatePlayerCareerStats(listOf(p1), listOf(m1, m2), editedStatsMap).first()
        assertEquals(67, rebuilt.runsScored)
        assertEquals(42, rebuilt.highestScore)
        assertEquals(2, rebuilt.bestBowlingWickets)
        assertEquals(12, rebuilt.bestBowlingRuns)
    }

    @Test
    fun step2_recalculateAllStatsAndStandingsFromMatchRecords_resetsStaleTotals() {
        val t = TournamentEntity(
            id = 1L,
            ownerUserId = 1L,
            name = "Rebuild Cup",
            oversPerMatch = 8,
            tournamentCode = "CM0022",
            editorCode = "ED0022",
            viewerCode = "VW0022"
        )
        val staleTeamA = TeamEntity(id = 1L, tournamentId = 1L, name = "Alpha", shortCode = "ALP", played = 9, won = 9, points = 99)
        val staleTeamB = TeamEntity(id = 2L, tournamentId = 1L, name = "Beta", shortCode = "BET", played = 9, won = 0, points = 0)
        val match = MatchEntity(
            id = 5L,
            tournamentId = 1L,
            stage = MatchStage.LEAGUE,
            teamAId = 1L,
            teamBId = 2L,
            teamAName = "Alpha",
            teamBName = "Beta",
            oversLimit = 8,
            status = MatchStatus.COMPLETED,
            battingFirstTeamId = 1L,
            teamARuns = 64,
            teamAWickets = 4,
            teamABalls = 48,
            teamBRuns = 68,
            teamBWickets = 3,
            teamBBalls = 42,
            playerOfMatchId = 20L
        )
        val standings = CricketStatsEngine.computeTeamStandings(listOf(staleTeamA, staleTeamB), listOf(match), t, allOutWickets = 8)
        assertEquals(1, standings.first { it.id == 2L }.won)
        assertEquals(2, standings.first { it.id == 2L }.points)
        assertEquals(0, standings.first { it.id == 1L }.won)
        assertEquals(0, standings.first { it.id == 1L }.points)

        val stalePlayer = PlayerEntity(id = 20L, tournamentId = 1L, teamId = 2L, name = "Star", runsScored = 500, highestScore = 150, wicketsTaken = 20)
        val statsMap = mapOf(
            5L to listOf(
                PlayerMatchStatEntity(
                    tournamentId = 1L, matchId = 5L, teamId = 2L, playerId = 20L, playerName = "Star",
                    innings = 2, didBat = true, runsScored = 31, ballsFaced = 18, didBowl = true, ballsBowled = 12, runsConceded = 14, wicketsTaken = 2
                )
            )
        )
        val rebuilt = CricketStatsEngine.aggregatePlayerCareerStats(listOf(stalePlayer), listOf(match), statsMap).first()
        assertEquals(31, rebuilt.runsScored)
        assertEquals(31, rebuilt.highestScore)
        assertEquals(2, rebuilt.wicketsTaken)
        assertEquals(1, rebuilt.playerOfMatchCount)
    }

    @Test
    fun step3_customTiebreakerOrderAndWalkoverAndDoubleRoundRobin_workWithoutHardcoding() {
        val t = TournamentEntity(
            id = 1L,
            ownerUserId = 1L,
            name = "Custom Rules Cup",
            oversPerMatch = 10,
            playersPerSide = 9,
            squadSize = 13,
            allOutWickets = 8,
            pointsWin = 2,
            pointsWalkover = 3,
            tiebreakerOrder = "POINTS,H2H,WINS,NRR,NAME",
            matchesPerPair = 2,
            tournamentCode = "CM0033",
            editorCode = "ED0033",
            viewerCode = "VW0033"
        )
        val a = TeamEntity(id = 1L, tournamentId = 1L, name = "A", shortCode = "A")
        val b = TeamEntity(id = 2L, tournamentId = 1L, name = "B", shortCode = "B")
        val fixtures = CricketStatsEngine.generateFixtures(
            tournamentId = 1L,
            teams = listOf(a, b),
            format = TournamentFormat.LEAGUE,
            oversPerMatch = t.oversPerMatch,
            scoringMode = ScoringMode.BALL_BY_BALL,
            venue = "Ground",
            startDateLabel = "2026-06-01",
            matchesPerPair = t.matchesPerPair
        )
        assertEquals(2, fixtures.size)

        val h2hWinByB = MatchEntity(
            id = 1L, tournamentId = 1L, stage = MatchStage.LEAGUE,
            teamAId = 1L, teamBId = 2L, teamAName = "A", teamBName = "B",
            status = MatchStatus.COMPLETED, winnerTeamId = 2L,
            teamARuns = 50, teamAWickets = 3, teamABalls = 60,
            teamBRuns = 55, teamBWickets = 2, teamBBalls = 60
        )
        val walkoverForA = MatchEntity(
            id = 2L, tournamentId = 1L, stage = MatchStage.LEAGUE,
            teamAId = 1L, teamBId = 2L, teamAName = "A", teamBName = "B",
            status = MatchStatus.WALKOVER, winnerTeamId = 1L
        )
        val standings = CricketStatsEngine.computeTeamStandings(listOf(a, b), listOf(h2hWinByB, walkoverForA), t)
        assertEquals(3, standings.first { it.id == 1L }.points) // 3 pts walkover

        // Force equal points to verify H2H tiebreaker when H2H is placed before WINS/NRR
        val tiedTeams = standings.map { it.copy(points = 4, won = 2) }
        val sortedByH2H = CricketStatsEngine.sortTeamsForPointsTable(tiedTeams, listOf(h2hWinByB), "POINTS,H2H,WINS,NRR,NAME")
        assertEquals(2L, sortedByH2H.first().id)
    }

    @Test
    fun step4_stageSpecificRules_copySnapshotsAndProtectHistoricalMatches() {
        val t = TournamentEntity(
            id = 1L,
            ownerUserId = 1L,
            name = "Stage Rules Cup",
            oversPerMatch = 10,
            playersPerSide = 10,
            squadSize = 14,
            allOutWickets = 9,
            maxOversPerBowler = 2,
            leaguePlayersPerSide = 8,
            leagueSquadSize = 12,
            leagueOvers = 8,
            finalPlayersPerSide = 11,
            finalSquadSize = 15,
            finalOvers = 20,
            tournamentCode = "CM0044",
            editorCode = "ED0044",
            viewerCode = "VW0044"
        )
        val leagueRules = CricketStatsEngine.effectiveStageRules(t, MatchStage.LEAGUE)
        assertEquals(8, leagueRules.playersPerSide)
        assertEquals(12, leagueRules.squadSize)
        assertEquals(8, leagueRules.overs)
        assertEquals(7, leagueRules.allOutWickets)

        val finalRules = CricketStatsEngine.effectiveStageRules(t, MatchStage.FINAL)
        assertEquals(11, finalRules.playersPerSide)
        assertEquals(15, finalRules.squadSize)
        assertEquals(20, finalRules.overs)
        assertEquals(10, finalRules.allOutWickets)

        val teamA = TeamEntity(id = 1L, tournamentId = 1L, name = "A", shortCode = "A")
        val teamB = TeamEntity(id = 2L, tournamentId = 1L, name = "B", shortCode = "B")
        val generated = CricketStatsEngine.generateFixtures(
            tournamentId = 1L,
            teams = listOf(teamA, teamB),
            format = TournamentFormat.LEAGUE,
            oversPerMatch = t.oversPerMatch,
            scoringMode = ScoringMode.BALL_BY_BALL,
            venue = "Ground",
            startDateLabel = "2026-06-01",
            tournament = t
        ).first()
        assertEquals(8, generated.oversLimit)
        assertEquals(8, generated.playersPerSideSnapshot)
        assertEquals(7, generated.allOutWicketsSnapshot)

        // Mutate tournament rules later: completed match must still use its copied snapshot
        val completedLeagueMatch = generated.copy(
            status = MatchStatus.COMPLETED,
            battingFirstTeamId = 1L,
            teamARuns = 40,
            teamAWickets = 7,
            teamABalls = 30,
            teamBRuns = 41,
            teamBWickets = 1,
            teamBBalls = 24
        )
        val modifiedTournament = t.copy(oversPerMatch = 20, playersPerSide = 11, allOutWickets = 10, leagueOvers = 0, leaguePlayersPerSide = 0)
        val standingsAfterRuleEdit = CricketStatsEngine.computeTeamStandings(listOf(teamA, teamB), listOf(completedLeagueMatch), modifiedTournament)
        // Snapshot kept 8 overs (48 balls) all-out for Team A even after tournament changed to 20 overs
        assertEquals(48, standingsAfterRuleEdit.first { it.id == 1L }.ballsFaced)
    }

    @Test
    fun step5_tournamentPresets_populateExactSettingsAndStayEditable() {
        val presets = CricketStatsEngine.TOURNAMENT_PRESETS
        assertEquals(3, presets.size)
        val t20 = presets.first { it.labelBn == "২০ ওভার সাধারণ" }
        assertEquals(20, t20.oversPerMatch)
        assertEquals(11, t20.playersPerSide)
        assertEquals(15, t20.squadSize)
        assertEquals(10, t20.allOutWickets)
        assertEquals(PitchType.FULL_PITCH, t20.pitchType)

        val t10 = presets.first { it.labelBn == "১০ ওভার" }
        assertEquals(10, t10.oversPerMatch)
        assertEquals(11, t10.playersPerSide)
        assertEquals(2, t10.maxOversPerBowler)

        val short8 = presets.first { it.labelBn == "৮ ওভার শর্ট পিচ, ৮ জন" }
        assertEquals(8, short8.oversPerMatch)
        assertEquals(8, short8.playersPerSide)
        assertEquals(12, short8.squadSize)
        assertEquals(7, short8.allOutWickets)
        assertEquals(PitchType.SHORT_PITCH, short8.pitchType)
    }

    @Test
    fun step6_mottNormalizedFormula_appliesFinalMultiplierAndNoPomDoubleCount() {
        val t = TournamentEntity(
            id = 1L,
            ownerUserId = 1L,
            name = "MOTT Cup",
            mottBattingWeight = 1.0,
            mottBowlingWeight = 1.0,
            mottBowlingWicketShare = 0.6,
            mottBowlingEconomyShare = 0.4,
            mottFinalMultiplier = 1.5,
            tournamentCode = "CM0066",
            editorCode = "ED0066",
            viewerCode = "VW0066"
        )
        val p1 = PlayerEntity(id = 1L, tournamentId = 1L, teamId = 1L, name = "Bat Final", playerOfMatchCount = 0)
        val p2 = PlayerEntity(id = 2L, tournamentId = 1L, teamId = 2L, name = "Bat League + POM", playerOfMatchCount = 5)
        val leagueMatch = MatchEntity(id = 10L, tournamentId = 1L, stage = MatchStage.LEAGUE, teamAId = 1L, teamBId = 2L, teamAName = "A", teamBName = "B", status = MatchStatus.COMPLETED)
        val finalMatch = MatchEntity(id = 11L, tournamentId = 1L, stage = MatchStage.FINAL, teamAId = 1L, teamBId = 2L, teamAName = "A", teamBName = "B", status = MatchStatus.COMPLETED)

        val stats = listOf(
            PlayerMatchStatEntity(tournamentId = 1L, matchId = 10L, teamId = 2L, playerId = 2L, playerName = "Bat League + POM", innings = 1, didBat = true, runsScored = 40, ballsFaced = 20),
            PlayerMatchStatEntity(tournamentId = 1L, matchId = 11L, teamId = 1L, playerId = 1L, playerName = "Bat Final", innings = 1, didBat = true, runsScored = 40, ballsFaced = 20)
        )
        val mottMap = CricketStatsEngine.calculateTournamentMottBreakdownMap(listOf(p1, p2), stats, listOf(leagueMatch, finalMatch), t)
        val p1Score = mottMap[1L]!!.totalScore
        val p2Score = mottMap[2L]!!.totalScore
        // Avg batter runs = 40.0. P2 league = 1.0 (no +20 POM bonus!), P1 final = 1.0 * 1.5 = 1.5
        assertEquals(1.5, p1Score, 0.001)
        assertEquals(1.0, p2Score, 0.001)
        assertTrue(p1Score > p2Score)
    }

    @Test
    fun step7_playingSelection_blocksOverLimitAndCountsNonBatNonBowlPlayers() {
        // 8-player limit blocks 9 selected players, allows 8; 11-player Final allows 11
        val ninePlayers = (1L..9L).toList()
        val eightPlayers = (1L..8L).toList()
        val elevenPlayers = (1L..11L).toList()
        assertNotNull(CricketStatsEngine.validatePlayingSelection(ninePlayers, 8))
        assertNull(CricketStatsEngine.validatePlayingSelection(eightPlayers, 8))
        assertNull(CricketStatsEngine.validatePlayingSelection(elevenPlayers, 11))

        val batter = PlayerEntity(id = 1L, tournamentId = 1L, teamId = 10L, name = "Opener")
        val specialistFielder = PlayerEntity(id = 2L, tournamentId = 1L, teamId = 10L, name = "Specialist Fielder")
        val benchPlayer = PlayerEntity(id = 3L, tournamentId = 1L, teamId = 10L, name = "Bench")

        val match = MatchEntity(
            id = 50L,
            tournamentId = 1L,
            teamAId = 10L,
            teamBId = 20L,
            teamAName = "A",
            teamBName = "B",
            status = MatchStatus.COMPLETED,
            playersPerSideSnapshot = 8,
            teamAPlayingIds = "1,2"
        )
        val balls = listOf(
            BallEventEntity(
                tournamentId = 1L,
                matchId = 50L,
                innings = 1,
                sequenceNumber = 1,
                overNumber = 0,
                ballInOver = 1,
                strikerId = 1L,
                nonStrikerId = 0L,
                bowlerId = 99L,
                runsOffBat = 4
            )
        )
        // Ball-by-ball path builds MatchStats including non-bat/non-bowl player #2 in playing XI
        val liveBuilt = CricketStatsEngine.buildMatchStatsFromBallEvents(match, listOf(batter, specialistFielder, benchPlayer), balls)
        assertEquals(2, liveBuilt.size)
        val rebuiltLive = CricketStatsEngine.aggregatePlayerCareerStats(
            players = listOf(batter, specialistFielder, benchPlayer),
            completedMatches = listOf(match),
            matchStatsByMatchId = mapOf(50L to liveBuilt)
        )
        assertEquals(1, rebuiltLive.first { it.id == 1L }.matchesPlayed)
        assertEquals(1, rebuiltLive.first { it.id == 1L }.inningsBatted)
        assertEquals(1, rebuiltLive.first { it.id == 2L }.matchesPlayed)
        assertEquals(0, rebuiltLive.first { it.id == 2L }.inningsBatted)
        assertEquals(0, rebuiltLive.first { it.id == 3L }.matchesPlayed)

        // Manual path where only batter had batting row, specialistFielder only in teamAPlayingIds
        val manualStatsOnlyBatter = liveBuilt.filter { it.playerId == 1L }
        val rebuiltManual = CricketStatsEngine.aggregatePlayerCareerStats(
            players = listOf(batter, specialistFielder, benchPlayer),
            completedMatches = listOf(match),
            matchStatsByMatchId = mapOf(50L to manualStatsOnlyBatter)
        )
        assertEquals(1, rebuiltManual.first { it.id == 2L }.matchesPlayed)
        assertEquals(0, rebuiltManual.first { it.id == 2L }.inningsBatted)
        assertEquals(0, rebuiltManual.first { it.id == 3L }.matchesPlayed)
    }

    @Test
    fun step8_sixTeamCircleOrderAndSequentialDates_neverSchedulesConsecutiveDays() {
        val teams6 = (1L..6L).map { idx ->
            TeamEntity(id = idx, tournamentId = 1L, name = "Team $idx", shortCode = "T$idx")
        }
        val fixtures6 = CricketStatsEngine.generateFixtures(
            tournamentId = 1L,
            teams = teams6,
            format = TournamentFormat.LEAGUE,
            oversPerMatch = 8,
            scoringMode = ScoringMode.BALL_BY_BALL,
            venue = "Ground",
            startDateLabel = "2026-05-15"
        )
        assertEquals(15, fixtures6.size)
        // Exact 6-team circle sequence: (0,5) (1,4) (2,3) ... (3,4)
        assertEquals(1L to 6L, fixtures6[0].teamAId to fixtures6[0].teamBId)
        assertEquals(2L to 5L, fixtures6[1].teamAId to fixtures6[1].teamBId)
        assertEquals(3L to 4L, fixtures6[2].teamAId to fixtures6[2].teamBId)
        assertEquals(4L to 5L, fixtures6[14].teamAId to fixtures6[14].teamBId)
        // Sequential daily dates (1 match per day)
        assertEquals("2026-05-15", fixtures6[0].scheduledDate)
        assertEquals("2026-05-16", fixtures6[1].scheduledDate)
        assertEquals("2026-05-29", fixtures6[14].scheduledDate)
        assertFalse(CricketStatsEngine.hasConsecutiveDayMatch(fixtures6))

        // Verify zero consecutive days for 5, 7, 8 teams too
        for (n in listOf(5, 7, 8)) {
            val tList = (1L..n.toLong()).map { idx -> TeamEntity(id = idx, tournamentId = 1L, name = "T$idx", shortCode = "T$idx") }
            val gen = CricketStatsEngine.generateFixtures(
                tournamentId = 1L,
                teams = tList,
                format = TournamentFormat.LEAGUE,
                oversPerMatch = 10,
                scoringMode = ScoringMode.BALL_BY_BALL,
                venue = "Ground",
                startDateLabel = "2026-05-28"
            )
            assertFalse("Team played consecutive days for n=$n", CricketStatsEngine.hasConsecutiveDayMatch(gen))
        }
        // Month rollover check
        assertEquals("2026-06-01", CricketStatsEngine.addDaysToYmd("2026-05-31", 1))
    }

    @Test
    fun step8_superOverTieWinner_resolvesExplicitWinnerOrRequiresSelection() {
        val unresolved = CricketStatsEngine.resolveMatchOutcome(
            teamAId = 1L, teamAName = "A", teamARuns = 85, teamAWickets = 5,
            teamBId = 2L, teamBName = "B", teamBRuns = 85, teamBWickets = 6,
            battingFirstTeamId = 1L, allOutWickets = 7,
            tieRule = TieRule.SUPER_OVER, superOverWinnerTeamId = 0L
        )
        assertEquals(0L, unresolved.first)

        val resolved = CricketStatsEngine.resolveMatchOutcome(
            teamAId = 1L, teamAName = "Team Alpha", teamARuns = 85, teamAWickets = 5,
            teamBId = 2L, teamBName = "Team Beta", teamBRuns = 85, teamBWickets = 6,
            battingFirstTeamId = 1L, allOutWickets = 7,
            tieRule = TieRule.SUPER_OVER, superOverWinnerTeamId = 2L
        )
        assertEquals(2L, resolved.first)
        assertTrue(resolved.second.contains("সুপার ওভারে জয়ী"))
    }

    @Test
    fun step9_lwwSyncConflictResolution_prefersNewerUpdatedAt() {
        val localOlder = MatchEntity(
            id = 1L, tournamentId = 1L, teamAId = 1L, teamBId = 2L,
            teamAName = "Alpha", teamBName = "Beta",
            teamARuns = 70, status = MatchStatus.LIVE, updatedAt = 1_000L
        )
        val remoteNewer = localOlder.copy(teamARuns = 95, status = MatchStatus.COMPLETED, updatedAt = 2_000L)
        assertEquals(95, CricketStatsEngine.resolveMatchLww(localOlder, remoteNewer).teamARuns)

        val localNewer = localOlder.copy(teamARuns = 110, status = MatchStatus.COMPLETED, updatedAt = 3_000L)
        assertEquals(110, CricketStatsEngine.resolveMatchLww(localNewer, remoteNewer).teamARuns)
        assertEquals(remoteNewer.teamARuns, CricketStatsEngine.resolveMatchLww(null, remoteNewer).teamARuns)
    }

    @Test
    fun step10_securityBackupValidation_coversStatsPasswordAndOvers() {
        assertFalse(CricketStatsEngine.isValidOversInput("7.8"))
        assertFalse(CricketStatsEngine.isValidOversInput("7.12"))
        assertFalse(CricketStatsEngine.isValidOversInput("abc"))
        assertTrue(CricketStatsEngine.isValidOversInput("7.5"))
        assertTrue(CricketStatsEngine.isValidOversInput("8"))
        assertTrue(CricketStatsEngine.isValidOversInput(""))

        val stat = PlayerMatchStatEntity(
            tournamentId = 1L, matchId = 2L, teamId = 3L, playerId = 4L,
            playerName = "Batter", innings = 1, didBat = true, runsScored = 55
        )
        val bundle = TournamentBackupBundle(
            tournament = TournamentEntity(
                ownerUserId = 1L, name = "Backup Cup",
                tournamentCode = AuthSecurity.generateCode("CM"),
                editorCode = AuthSecurity.generateCode("ED"),
                viewerCode = AuthSecurity.generateCode("VW")
            ),
            teams = emptyList(),
            players = emptyList(),
            matches = emptyList(),
            balls = emptyList(),
            members = emptyList(),
            logs = emptyList(),
            playerMatchStats = listOf(stat)
        )
        assertEquals(1, bundle.playerMatchStats.size)
        assertEquals(55, bundle.playerMatchStats.first().runsScored)
    }

    @Test
    fun winMargin_usesBattingFirstAndAllOutWickets() {
        // Team B batted first (battingFirstTeamId = 2L), scored 90; Team A chased 91/2 (all out = 8) -> Team A won by 6 wickets
        val chaseOutcome = CricketStatsEngine.resolveMatchOutcome(
            teamAId = 1L, teamAName = "Team A", teamARuns = 91, teamAWickets = 2,
            teamBId = 2L, teamBName = "Team B", teamBRuns = 90, teamBWickets = 5,
            battingFirstTeamId = 2L, allOutWickets = 8
        )
        assertEquals(1L, chaseOutcome.first)
        assertTrue(chaseOutcome.second.contains("6 উইকেটে"))

        // Team B batted first and defended 90 vs 80 -> Team B won by 10 runs
        val defendOutcome = CricketStatsEngine.resolveMatchOutcome(
            teamAId = 1L, teamAName = "Team A", teamARuns = 80, teamAWickets = 6,
            teamBId = 2L, teamBName = "Team B", teamBRuns = 90, teamBWickets = 5,
            battingFirstTeamId = 2L, allOutWickets = 8
        )
        assertEquals(2L, defendOutcome.first)
        assertTrue(defendOutcome.second.contains("10 রানে"))
    }

    @Test
    fun oversFormattingAndParsing_roundTripsCorrectly() {
        assertEquals("0.0", CricketStatsEngine.formatOvers(0))
        assertEquals("3.4", CricketStatsEngine.formatOvers(22))
        assertEquals(22, CricketStatsEngine.parseOversToBalls("3.4"))
        assertEquals(48, CricketStatsEngine.parseOversToBalls("8"))
    }

    @Test
    fun ballChipFormatting_handlesExtrasAndWickets() {
        assertEquals("•", CricketStatsEngine.formatBallChip(0, 0, ExtraType.NONE, false))
        assertEquals("4", CricketStatsEngine.formatBallChip(4, 0, ExtraType.NONE, false))
        assertEquals("Wd", CricketStatsEngine.formatBallChip(0, 1, ExtraType.WIDE, false))
        assertEquals("W", CricketStatsEngine.formatBallChip(0, 0, ExtraType.NONE, true))
        assertTrue(CricketStatsEngine.isLegalDelivery(ExtraType.BYE))
        assertFalse(CricketStatsEngine.isLegalDelivery(ExtraType.WIDE))
    }

    @Test
    fun passwordHash_andConverters_workDeterministically() {
        val hash = AuthSecurity.hashPassword("secret123")
        assertTrue(AuthSecurity.verifyPassword("secret123", hash))
        assertFalse(AuthSecurity.verifyPassword("wrong", hash))

        val conv = Converters()
        assertEquals(PitchType.SHORT_PITCH, conv.toPitchType(conv.fromPitchType(PitchType.SHORT_PITCH)))
        assertEquals(ScoringMode.MANUAL, conv.toScoringMode(conv.fromScoringMode(ScoringMode.MANUAL)))
        assertEquals(TournamentFormat.GROUP_KNOCKOUT, conv.toTournamentFormat(conv.fromTournamentFormat(TournamentFormat.GROUP_KNOCKOUT)))
        assertEquals(MatchStage.SEMI_FINAL, conv.toMatchStage(conv.fromMatchStage(MatchStage.SEMI_FINAL)))
        assertEquals(PlayerRole.WICKET_KEEPER, conv.toPlayerRole(conv.fromPlayerRole(PlayerRole.WICKET_KEEPER)))
        assertEquals(WicketType.LBW, conv.toWicketType(conv.fromWicketType(WicketType.LBW)))
        assertEquals(UserRole.EDITOR, conv.toUserRole(conv.fromUserRole(UserRole.EDITOR)))
    }
}
