package com.cricketmanager.app.data.repository

import android.content.Context
import com.cricketmanager.app.data.local.AuditLogEntity
import com.cricketmanager.app.data.local.BallEventEntity
import com.cricketmanager.app.data.local.CricketDao
import com.cricketmanager.app.data.local.CricketDatabase
import com.cricketmanager.app.data.local.ExtraType
import com.cricketmanager.app.data.local.MatchEntity
import com.cricketmanager.app.data.local.MatchStage
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.PitchType
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.PlayerMatchStatEntity
import com.cricketmanager.app.data.local.PlayerRole
import com.cricketmanager.app.data.local.PlayoffType
import com.cricketmanager.app.data.local.ScoringMode
import com.cricketmanager.app.data.local.TeamEntity
import com.cricketmanager.app.data.local.TieRule
import com.cricketmanager.app.data.local.TournamentEntity
import com.cricketmanager.app.data.local.TournamentFormat
import com.cricketmanager.app.data.local.TournamentMemberEntity
import com.cricketmanager.app.data.local.UserEntity
import com.cricketmanager.app.data.local.UserPreferences
import com.cricketmanager.app.data.local.UserRole
import com.cricketmanager.app.data.local.WicketType
import com.cricketmanager.app.domain.AuthSecurity
import com.cricketmanager.app.domain.BackupSerializer
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.domain.TournamentBackupBundle
import com.cricketmanager.app.sync.CloudSyncResult
import com.cricketmanager.app.sync.FirebaseSyncBridge
import com.cricketmanager.app.sync.TournamentSyncWorker
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

data class TeamDraft(
    val name: String,
    val shortCode: String,
    val logoEmoji: String,
    val captainName: String,
    val groupName: String
)

class CricketRepository(
    private val dao: CricketDao,
    private val preferences: UserPreferences,
    private val firebaseSyncBridge: FirebaseSyncBridge,
    private val appContext: Context
) {
    val usersFlow: Flow<List<UserEntity>> = dao.observeAllUsers()
    val tournamentsFlow: Flow<List<TournamentEntity>> = dao.observeAllTournaments()
    val teamsFlow: Flow<List<TeamEntity>> = dao.observeAllTeams()
    val playersFlow: Flow<List<PlayerEntity>> = dao.observeAllPlayers()
    val matchesFlow: Flow<List<MatchEntity>> = dao.observeAllMatches()
    val ballEventsFlow: Flow<List<BallEventEntity>> = dao.observeAllBallEvents()
    val membersFlow: Flow<List<TournamentMemberEntity>> = dao.observeAllMembers()
    val auditLogsFlow: Flow<List<AuditLogEntity>> = dao.observeAllAuditLogs()
    val playerMatchStatsFlow: Flow<List<PlayerMatchStatEntity>> = dao.observeAllPlayerMatchStats()

    val activeUserIdFlow: Flow<Long> = preferences.activeUserIdFlow
    val selectedTournamentIdFlow: Flow<Long> = preferences.selectedTournamentIdFlow
    val languageCodeFlow: Flow<String> = preferences.languageCodeFlow
    val autoSyncFlow: Flow<Boolean> = preferences.autoSyncFlow
    val lastSyncAtFlow: Flow<Long> = preferences.lastSyncAtFlow

    fun isFirebaseConfigured(): Boolean = firebaseSyncBridge.isFirebaseConfigured()

    suspend fun ensureSeeded(db: CricketDatabase) {
        val currentUserId = preferences.activeUserIdFlow.first()
        if (currentUserId > 0L) {
            val firstTournament = dao.getAllTournamentsOnce().firstOrNull()
            if (firstTournament != null) {
                preferences.setSelectedTournamentId(firstTournament.id)
            }
        }
    }

    suspend fun registerUser(
        fullName: String,
        email: String,
        password: String,
        organization: String
    ): Result<UserEntity> {
        val cleanEmail = email.trim().lowercase()
        val cleanPassword = password.trim()
        if (cleanEmail.isBlank() || cleanPassword.length < 6) {
            return Result.failure(IllegalArgumentException("সঠিক ইমেইল এবং কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন।"))
        }
        val existing = dao.getUserByEmail(cleanEmail)
        if (existing != null) {
            return Result.failure(IllegalStateException("Account already exists with this email."))
        }
        val user = UserEntity(
            fullName = fullName.trim().ifBlank { "Cricket Organizer" },
            email = cleanEmail,
            passwordHash = AuthSecurity.hashPassword(cleanPassword),
            organization = organization.trim()
        )
        val id = dao.insertUser(user)
        val saved = user.copy(id = id)
        preferences.setActiveUserId(id)
        if (firebaseSyncBridge.isFirebaseConfigured()) {
            firebaseSyncBridge.signInOrRegisterFirebase(cleanEmail, cleanPassword)
        }
        return Result.success(saved)
    }

    suspend fun loginUser(email: String, password: String): Result<UserEntity> {
        val cleanEmail = email.trim().lowercase()
        val user = dao.getUserByEmail(cleanEmail)
            ?: return Result.failure(IllegalArgumentException("No account found for this email."))
        if (!AuthSecurity.verifyPassword(password, user.passwordHash)) {
            return Result.failure(IllegalArgumentException("Incorrect password."))
        }
        preferences.setActiveUserId(user.id)
        if (firebaseSyncBridge.isFirebaseConfigured()) {
            firebaseSyncBridge.signInOrRegisterFirebase(cleanEmail, password)
        }
        return Result.success(user)
    }

    suspend fun continueAsGuestDemo(db: CricketDatabase) {
        val seededUserId = CricketDatabase.seedDemoDataIfEmpty(db)
        val existing = dao.getUserByEmail("organizer@cricketmanager.app")
        if (existing != null) {
            preferences.setActiveUserId(existing.id)
        } else if (seededUserId != null) {
            preferences.setActiveUserId(seededUserId)
        } else {
            val id = dao.insertUser(
                UserEntity(
                    fullName = "Guest Organizer",
                    email = "guest@cricketmanager.app",
                    passwordHash = AuthSecurity.hashPassword(AuthSecurity.generateCode("GST")),
                    organization = "Local Club"
                )
            )
            preferences.setActiveUserId(id)
        }
        val firstTournament = dao.getAllTournamentsOnce().firstOrNull()
        if (firstTournament != null) {
            preferences.setSelectedTournamentId(firstTournament.id)
        }
    }

    suspend fun logout() {
        preferences.setActiveUserId(0L)
    }

    suspend fun selectTournament(tournamentId: Long) {
        preferences.setSelectedTournamentId(tournamentId)
    }

    suspend fun setLanguage(code: String) {
        preferences.setLanguageCode(code)
    }

    suspend fun setAutoSync(enabled: Boolean) {
        preferences.setAutoSync(enabled)
    }

    suspend fun createTournamentWithTeams(
        ownerUser: UserEntity,
        name: String,
        logoEmoji: String,
        organizationName: String,
        pitchType: PitchType,
        scoringMode: ScoringMode,
        format: TournamentFormat,
        oversPerMatch: Int,
        playersPerSide: Int = 11,
        squadSize: Int = 15,
        allOutWickets: Int = 10,
        maxOversPerBowler: Int = 4,
        groupCount: Int,
        rulesSummary: String,
        pointsWin: Int,
        pointsTie: Int,
        pointsLoss: Int,
        pointsAbandoned: Int,
        pointsWalkover: Int = 2,
        tiebreakerOrder: String = "POINTS,WINS,NRR,H2H,NAME",
        tieRule: TieRule = TieRule.SHARE_POINTS,
        matchesPerPair: Int = 1,
        playoffType: PlayoffType = PlayoffType.SEMI_FINAL,
        playoffTeamsCount: Int = 4,
        leaguePlayersPerSide: Int = 0,
        leagueSquadSize: Int = 0,
        leagueOvers: Int = 0,
        playoffPlayersPerSide: Int = 0,
        playoffSquadSize: Int = 0,
        playoffOvers: Int = 0,
        finalPlayersPerSide: Int = 0,
        finalSquadSize: Int = 0,
        finalOvers: Int = 0,
        mottBattingWeight: Double = 1.0,
        mottBowlingWeight: Double = 1.0,
        mottBowlingWicketShare: Double = 0.6,
        mottBowlingEconomyShare: Double = 0.4,
        mottFinalMultiplier: Double = 1.5,
        location: String,
        startDateLabel: String,
        teamDrafts: List<TeamDraft>
    ): Long {
        val safePlayers = playersPerSide.coerceIn(2, 15)
        val safeSquad = squadSize.coerceIn(safePlayers, 30)
        val safeAllOut = allOutWickets.coerceIn(1, (safePlayers - 1).coerceAtLeast(1))
        val safeOvers = oversPerMatch.coerceIn(1, 50)
        val safeBowlerMax = maxOversPerBowler.coerceIn(1, safeOvers)
        val safePairs = matchesPerPair.coerceIn(1, 2)
        val safePlayoffTeams = playoffTeamsCount.coerceIn(2, 16)

        val newTournament = TournamentEntity(
            ownerUserId = ownerUser.id,
            name = name.trim(),
            logoEmoji = logoEmoji.ifBlank { "🏆" },
            organizationName = organizationName.trim(),
            pitchType = pitchType,
            scoringMode = scoringMode,
            format = format,
            oversPerMatch = safeOvers,
            playersPerSide = safePlayers,
            squadSize = safeSquad,
            allOutWickets = safeAllOut,
            maxOversPerBowler = safeBowlerMax,
            maxTeams = teamDrafts.size.coerceAtLeast(2),
            groupCount = groupCount.coerceIn(1, 4),
            rulesSummary = rulesSummary.trim(),
            pointsWin = pointsWin,
            pointsTie = pointsTie,
            pointsLoss = pointsLoss,
            pointsAbandoned = pointsAbandoned,
            pointsWalkover = pointsWalkover,
            tiebreakerOrder = tiebreakerOrder.ifBlank { "POINTS,WINS,NRR,H2H,NAME" },
            tieRule = tieRule,
            matchesPerPair = safePairs,
            playoffType = playoffType,
            playoffTeamsCount = safePlayoffTeams,
            leaguePlayersPerSide = leaguePlayersPerSide.coerceAtLeast(0),
            leagueSquadSize = leagueSquadSize.coerceAtLeast(0),
            leagueOvers = leagueOvers.coerceAtLeast(0),
            playoffPlayersPerSide = playoffPlayersPerSide.coerceAtLeast(0),
            playoffSquadSize = playoffSquadSize.coerceAtLeast(0),
            playoffOvers = playoffOvers.coerceAtLeast(0),
            finalPlayersPerSide = finalPlayersPerSide.coerceAtLeast(0),
            finalSquadSize = finalSquadSize.coerceAtLeast(0),
            finalOvers = finalOvers.coerceAtLeast(0),
            mottBattingWeight = mottBattingWeight.coerceAtLeast(0.0),
            mottBowlingWeight = mottBowlingWeight.coerceAtLeast(0.0),
            mottBowlingWicketShare = mottBowlingWicketShare.coerceAtLeast(0.0),
            mottBowlingEconomyShare = mottBowlingEconomyShare.coerceAtLeast(0.0),
            mottFinalMultiplier = mottFinalMultiplier.coerceAtLeast(0.5),
            tournamentCode = AuthSecurity.generateCode("CM"),
            editorCode = AuthSecurity.generateCode("ED"),
            viewerCode = AuthSecurity.generateCode("VW"),
            startDateLabel = startDateLabel.ifBlank { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date()) },
            location = location.ifBlank { "Main Ground" },
            syncDirty = true
        )
        val tId = dao.insertTournament(newTournament)
        val persistedTournament = newTournament.copy(id = tId)

        dao.insertMember(
            TournamentMemberEntity(
                tournamentId = tId,
                userId = ownerUser.id,
                userName = ownerUser.fullName,
                userEmail = ownerUser.email,
                role = UserRole.OWNER,
                canEditTeams = true,
                canEditSchedule = true,
                canScore = true
            )
        )

        val insertedTeams = mutableListOf<TeamEntity>()
        teamDrafts.forEachIndexed { idx, draft ->
            val team = TeamEntity(
                tournamentId = tId,
                name = draft.name.trim(),
                shortCode = draft.shortCode.trim().uppercase().take(4).ifBlank { "T${idx + 1}" },
                logoEmoji = draft.logoEmoji.ifBlank { "🏏" },
                captainName = draft.captainName.trim(),
                groupName = draft.groupName.ifBlank { "Group A" },
                homeGround = location.ifBlank { "Main Ground" }
            )
            val teamId = dao.insertTeam(team)
            insertedTeams.add(team.copy(id = teamId))

            if (draft.captainName.isNotBlank()) {
                dao.insertPlayer(
                    PlayerEntity(
                        tournamentId = tId,
                        teamId = teamId,
                        name = draft.captainName.trim(),
                        jerseyNumber = 1,
                        role = PlayerRole.ALL_ROUNDER,
                        isCaptain = true
                    )
                )
            }
        }

        val fixtures = CricketStatsEngine.generateFixtures(
            tournamentId = tId,
            teams = insertedTeams,
            format = format,
            oversPerMatch = safeOvers,
            scoringMode = scoringMode,
            venue = location.ifBlank { "Main Ground" },
            startDateLabel = newTournament.startDateLabel,
            matchesPerPair = safePairs,
            tournament = persistedTournament
        )
        dao.insertMatches(fixtures)

        dao.insertAuditLog(
            AuditLogEntity(
                tournamentId = tId,
                actorName = ownerUser.fullName,
                actionTitle = "Created Tournament",
                details = "Created $name with ${insertedTeams.size} teams & ${fixtures.size} matches."
            )
        )

        preferences.setSelectedTournamentId(tId)
        TournamentSyncWorker.enqueueImmediateSync(appContext)
        return tId
    }

    suspend fun updateTournamentRules(updated: TournamentEntity, actorName: String) {
        dao.updateTournament(updated.copy(syncDirty = true, updatedAt = System.currentTimeMillis()))
        dao.recalculateTournamentStandings(updated.id)
        logAndMarkDirty(
            updated.id,
            actorName,
            "Updated Tournament Rules",
            "Updated rules: ${updated.playersPerSide} players, ${updated.oversPerMatch} ov, all-out ${updated.allOutWickets}, tiebreaker ${updated.tiebreakerOrder}."
        )
    }

    suspend fun markMatchWalkover(matchId: Long, winnerTeamId: Long, actorName: String) {
        val m = dao.getMatchById(matchId) ?: return
        val winnerName = if (winnerTeamId == m.teamBId) m.teamBName else m.teamAName
        dao.updateMatch(
            m.copy(
                status = MatchStatus.WALKOVER,
                winnerTeamId = winnerTeamId,
                resultSummary = "$winnerName জয়ী (ওয়াকওভার)",
                updatedAt = System.currentTimeMillis()
            )
        )
        dao.recalculateTournamentStandings(m.tournamentId)
        logAndMarkDirty(m.tournamentId, actorName, "Walkover Recorded", "Match #${m.matchNumber}: $winnerName awarded walkover.")
    }

    suspend fun joinAsViewerByCode(code: String): Result<TournamentEntity> {
        val clean = code.trim().uppercase()
        if (clean.isBlank()) {
            return Result.failure(IllegalArgumentException("দর্শক কোড লিখুন।"))
        }
        val viewerEmail = "viewer@cricketmanager.app"
        val existingViewer = dao.getUserByEmail(viewerEmail)
        val viewerUserId = existingViewer?.id ?: dao.insertUser(
            UserEntity(
                fullName = "Tournament Viewer",
                email = viewerEmail,
                passwordHash = AuthSecurity.hashPassword(AuthSecurity.generateCode("VWKEY")),
                organization = "Public Viewer"
            )
        )
        preferences.setActiveUserId(viewerUserId)
        val viewerUser = dao.getUserById(viewerUserId)
            ?: return Result.failure(IllegalStateException("Viewer session error."))

        var tournament = dao.findTournamentByAnyCode(clean)
        if (tournament == null && firebaseSyncBridge.isFirebaseConfigured()) {
            tournament = pullAndMergeRemoteTournamentByCode(clean, viewerUserId)
        }
        if (tournament == null) {
            return Result.failure(IllegalArgumentException("কোড $clean এর সাথে কোনো টুর্নামেন্ট মেলেনি।"))
        }

        val existingMember = dao.getMember(tournament.id, viewerUser.id)
        if (existingMember == null && tournament.ownerUserId != viewerUser.id) {
            dao.insertMember(
                TournamentMemberEntity(
                    tournamentId = tournament.id,
                    userId = viewerUser.id,
                    userName = viewerUser.fullName,
                    userEmail = viewerUser.email,
                    role = UserRole.VIEWER,
                    canEditTeams = false,
                    canEditSchedule = false,
                    canScore = false
                )
            )
        }
        preferences.setSelectedTournamentId(tournament.id)
        return Result.success(tournament)
    }

    suspend fun joinTournamentByCode(code: String, user: UserEntity): Result<Pair<TournamentEntity, UserRole>> {
        val clean = code.trim().uppercase()
        if (clean.isBlank()) {
            return Result.failure(IllegalArgumentException("Enter a valid tournament code."))
        }
        var tournament = dao.findTournamentByAnyCode(clean)
        if (tournament == null && firebaseSyncBridge.isFirebaseConfigured()) {
            tournament = pullAndMergeRemoteTournamentByCode(clean, user.id)
        }
        if (tournament == null) {
            return Result.failure(IllegalArgumentException("No tournament matches code $clean."))
        }

        val assignedRole = when {
            clean == tournament.editorCode.uppercase() -> UserRole.EDITOR
            clean == tournament.viewerCode.uppercase() -> UserRole.VIEWER
            clean == tournament.tournamentCode.uppercase() -> UserRole.VIEWER
            else -> UserRole.VIEWER
        }

        val existingMember = dao.getMember(tournament.id, user.id)
        if (existingMember == null) {
            dao.insertMember(
                TournamentMemberEntity(
                    tournamentId = tournament.id,
                    userId = user.id,
                    userName = user.fullName,
                    userEmail = user.email,
                    role = assignedRole,
                    canEditTeams = assignedRole == UserRole.ADMIN || assignedRole == UserRole.OWNER,
                    canEditSchedule = assignedRole == UserRole.ADMIN || assignedRole == UserRole.OWNER,
                    canScore = assignedRole != UserRole.VIEWER
                )
            )
            dao.insertAuditLog(
                AuditLogEntity(
                    tournamentId = tournament.id,
                    actorName = user.fullName,
                    actionTitle = "Joined Tournament",
                    details = "${user.fullName} joined as ${assignedRole.labelEn} via code $clean."
                )
            )
        } else if (assignedRole == UserRole.EDITOR && existingMember.role == UserRole.VIEWER) {
            dao.updateMember(
                existingMember.copy(
                    role = UserRole.EDITOR,
                    canScore = true
                )
            )
        }

        preferences.setSelectedTournamentId(tournament.id)
        return Result.success(tournament to (existingMember?.role ?: assignedRole))
    }

    private suspend fun pullAndMergeRemoteTournamentByCode(cleanCode: String, userId: Long): TournamentEntity? {
        val pulled = firebaseSyncBridge.pullTournamentByCode(cleanCode, userId).getOrNull() ?: return null
        val mergedId = mergeRemoteTournamentBundle(pulled, userId)
        return dao.getTournamentById(mergedId)
    }

    suspend fun mergeRemoteTournamentBundle(bundle: TournamentBackupBundle, currentUserId: Long): Long {
        val existing = dao.findTournamentByAnyCode(bundle.tournament.tournamentCode)
        if (existing == null) {
            return dao.replaceTournamentBundle(
                tournament = bundle.tournament.copy(ownerUserId = currentUserId, syncDirty = false),
                teams = bundle.teams,
                players = bundle.players,
                matches = bundle.matches,
                balls = bundle.balls,
                members = bundle.members,
                logs = bundle.logs,
                playerMatchStats = bundle.playerMatchStats
            )
        }

        if (bundle.tournament.updatedAt > existing.updatedAt) {
            dao.updateTournament(
                bundle.tournament.copy(
                    id = existing.id,
                    ownerUserId = existing.ownerUserId,
                    syncDirty = false
                )
            )
        }

        val localTeams = dao.getTeamsByTournamentOnce(existing.id)
        val teamIdMap = mutableMapOf<Long, Long>()
        for (remoteTeam in bundle.teams) {
            val matched = localTeams.firstOrNull {
                it.name.equals(remoteTeam.name, ignoreCase = true) ||
                    it.shortCode.equals(remoteTeam.shortCode, ignoreCase = true)
            }
            if (matched != null) {
                teamIdMap[remoteTeam.id] = matched.id
            } else {
                teamIdMap[remoteTeam.id] = dao.insertTeam(remoteTeam.copy(id = 0, tournamentId = existing.id))
            }
        }

        val localMatches = dao.getMatchesByTournamentOnce(existing.id)
        for (remoteMatch in bundle.matches) {
            val localMatch = localMatches.firstOrNull {
                it.matchNumber == remoteMatch.matchNumber && it.stage == remoteMatch.stage
            }
            val winner = CricketStatsEngine.resolveMatchLww(localMatch, remoteMatch)
            if (localMatch == null) {
                dao.insertMatch(
                    remoteMatch.copy(
                        id = 0,
                        tournamentId = existing.id,
                        teamAId = teamIdMap[remoteMatch.teamAId] ?: remoteMatch.teamAId,
                        teamBId = teamIdMap[remoteMatch.teamBId] ?: remoteMatch.teamBId,
                        battingFirstTeamId = teamIdMap[remoteMatch.battingFirstTeamId] ?: 0L,
                        winnerTeamId = teamIdMap[remoteMatch.winnerTeamId] ?: 0L
                    )
                )
            } else if (winner === remoteMatch) {
                dao.updateMatch(
                    remoteMatch.copy(
                        id = localMatch.id,
                        tournamentId = existing.id,
                        teamAId = localMatch.teamAId,
                        teamBId = localMatch.teamBId,
                        battingFirstTeamId = teamIdMap[remoteMatch.battingFirstTeamId] ?: localMatch.battingFirstTeamId,
                        winnerTeamId = teamIdMap[remoteMatch.winnerTeamId] ?: 0L
                    )
                )
            }
        }

        dao.rebuildTournamentPlayerStats(existing.id)
        dao.recalculateTournamentStandings(existing.id)
        return existing.id
    }

    suspend fun addTeam(
        tournamentId: Long,
        name: String,
        shortCode: String,
        logoEmoji: String,
        captainName: String,
        groupName: String,
        homeGround: String,
        actorName: String
    ) {
        val id = dao.insertTeam(
            TeamEntity(
                tournamentId = tournamentId,
                name = name.trim(),
                shortCode = shortCode.trim().uppercase().take(4).ifBlank { "TM" },
                logoEmoji = logoEmoji.ifBlank { "🏏" },
                captainName = captainName.trim(),
                groupName = groupName.ifBlank { "Group A" },
                homeGround = homeGround.trim()
            )
        )
        if (captainName.isNotBlank()) {
            dao.insertPlayer(
                PlayerEntity(
                    tournamentId = tournamentId,
                    teamId = id,
                    name = captainName.trim(),
                    jerseyNumber = 1,
                    role = PlayerRole.ALL_ROUNDER,
                    isCaptain = true
                )
            )
        }
        logAndMarkDirty(tournamentId, actorName, "Added Team", "Added team $name ($groupName).")
    }

    suspend fun deleteTeam(team: TeamEntity, actorName: String) {
        dao.deleteTeam(team.id)
        logAndMarkDirty(team.tournamentId, actorName, "Deleted Team", "Removed team ${team.name}.")
    }

    suspend fun addPlayer(
        tournamentId: Long,
        teamId: Long,
        name: String,
        jerseyNumber: Int,
        role: PlayerRole,
        battingStyle: String,
        bowlingStyle: String,
        photoEmoji: String,
        isCaptain: Boolean,
        actorName: String
    ) {
        dao.insertPlayer(
            PlayerEntity(
                tournamentId = tournamentId,
                teamId = teamId,
                name = name.trim(),
                jerseyNumber = jerseyNumber,
                role = role,
                battingStyle = battingStyle.ifBlank { "Right-hand Bat" },
                bowlingStyle = bowlingStyle.ifBlank { "Right-arm Medium" },
                photoEmoji = photoEmoji.ifBlank { "🧑" },
                isCaptain = isCaptain
            )
        )
        logAndMarkDirty(tournamentId, actorName, "Added Player", "Registered player $name.")
    }

    suspend fun deletePlayer(player: PlayerEntity, actorName: String) {
        dao.deletePlayer(player.id)
        logAndMarkDirty(player.tournamentId, actorName, "Removed Player", "Removed ${player.name}.")
    }

    suspend fun updatePlayerStatsDirect(
        player: PlayerEntity,
        matchesPlayed: Int,
        runsScored: Int,
        ballsFaced: Int,
        fours: Int,
        sixes: Int,
        highestScore: Int,
        wicketsTaken: Int,
        runsConceded: Int,
        oversBowledText: String,
        actorName: String
    ) {
        val ballsBowled = CricketStatsEngine.parseOversToBalls(oversBowledText)
        dao.updatePlayer(
            player.copy(
                matchesPlayed = matchesPlayed.coerceAtLeast(0),
                inningsBatted = if (runsScored > 0 || ballsFaced > 0) maxOf(player.inningsBatted, 1) else player.inningsBatted,
                runsScored = runsScored.coerceAtLeast(0),
                ballsFaced = ballsFaced.coerceAtLeast(0),
                fours = fours.coerceAtLeast(0),
                sixes = sixes.coerceAtLeast(0),
                highestScore = maxOf(highestScore.coerceAtLeast(0), runsScored.coerceAtLeast(0)),
                wicketsTaken = wicketsTaken.coerceAtLeast(0),
                runsConceded = runsConceded.coerceAtLeast(0),
                ballsBowled = ballsBowled.coerceAtLeast(0)
            )
        )
        logAndMarkDirty(player.tournamentId, actorName, "Updated Player Stats", "Edited individual stats for ${player.name}.")
    }

    suspend fun createMatch(
        tournament: TournamentEntity,
        teamA: TeamEntity,
        teamB: TeamEntity,
        stage: MatchStage,
        groupName: String,
        venue: String,
        scheduledDate: String,
        scheduledTime: String,
        oversLimit: Int,
        scoringMode: ScoringMode,
        actorName: String
    ): Long {
        val currentMatches = dao.getMatchesByTournamentOnce(tournament.id)
        val nextNum = (currentMatches.maxOfOrNull { it.matchNumber } ?: 0) + 1
        val rules = CricketStatsEngine.effectiveStageRules(tournament, stage)
        val resolvedOvers = if (oversLimit > 0) oversLimit.coerceIn(1, 50) else rules.overs
        val matchId = dao.insertMatch(
            MatchEntity(
                tournamentId = tournament.id,
                matchNumber = nextNum,
                stage = stage,
                groupName = groupName,
                teamAId = teamA.id,
                teamBId = teamB.id,
                teamAName = teamA.name,
                teamBName = teamB.name,
                venue = venue.ifBlank { tournament.location },
                scheduledDate = scheduledDate.ifBlank { tournament.startDateLabel },
                scheduledTime = scheduledTime.ifBlank { "15:00" },
                oversLimit = resolvedOvers,
                playersPerSideSnapshot = rules.playersPerSide,
                squadSizeSnapshot = rules.squadSize,
                allOutWicketsSnapshot = rules.allOutWickets,
                maxOversPerBowlerSnapshot = if (resolvedOvers == rules.overs) rules.maxOversPerBowler else ((resolvedOvers + 4) / 5).coerceIn(1, resolvedOvers),
                scoringMode = scoringMode,
                status = MatchStatus.UPCOMING
            )
        )
        logAndMarkDirty(tournament.id, actorName, "Scheduled Match", "Match #$nextNum: ${teamA.name} vs ${teamB.name}.")
        return matchId
    }

    suspend fun generateKnockoutStage(tournament: TournamentEntity, stage: MatchStage, actorName: String): Result<Int> {
        if (tournament.playoffType == PlayoffType.NONE) {
            return Result.failure(IllegalStateException("এই টুর্নামেন্টে প্লে-অফ বন্ধ আছে"))
        }
        val existingMatches = dao.getMatchesByTournamentOnce(tournament.id)
        if (existingMatches.any { it.stage == stage }) {
            return Result.failure(IllegalStateException("${stage.labelBn} আগেই তৈরি করা আছে"))
        }
        val rankedTeams = CricketStatsEngine.sortTeamsForPointsTable(
            dao.getTeamsByTournamentOnce(tournament.id),
            existingMatches,
            tournament.tiebreakerOrder
        )
        if (rankedTeams.size < 2) {
            return Result.failure(IllegalStateException("Need at least 2 teams to generate stage."))
        }
        val qualified = rankedTeams.take(tournament.playoffTeamsCount.coerceIn(2, rankedTeams.size))
        var nextNum = (existingMatches.maxOfOrNull { it.matchNumber } ?: 0) + 1
        val lastDate = existingMatches.maxByOrNull { it.matchNumber }?.scheduledDate ?: tournament.startDateLabel
        var nextDayOffset = 1
        val newMatches = mutableListOf<MatchEntity>()
        val stageRules = CricketStatsEngine.effectiveStageRules(tournament, stage)

        fun buildStageMatch(groupTitle: String, teamA: TeamEntity, teamB: TeamEntity): MatchEntity {
            val mDate = CricketStatsEngine.addDaysToYmd(lastDate, nextDayOffset++)
            return MatchEntity(
                tournamentId = tournament.id,
                matchNumber = nextNum++,
                stage = stage,
                groupName = groupTitle,
                teamAId = teamA.id,
                teamBId = teamB.id,
                teamAName = teamA.name,
                teamBName = teamB.name,
                venue = tournament.location,
                scheduledDate = mDate,
                scheduledTime = "15:00",
                oversLimit = stageRules.overs,
                playersPerSideSnapshot = stageRules.playersPerSide,
                squadSizeSnapshot = stageRules.squadSize,
                allOutWicketsSnapshot = stageRules.allOutWickets,
                maxOversPerBowlerSnapshot = stageRules.maxOversPerBowler,
                scoringMode = tournament.scoringMode
            )
        }

        when (stage) {
            MatchStage.SEMI_FINAL -> {
                if (qualified.size < 4) {
                    return Result.failure(IllegalStateException("সেমিফাইনালের জন্য অন্তত ৪টি যোগ্য দল প্রয়োজন"))
                }
                newMatches.add(buildStageMatch("Semi-Final 1", qualified[0], qualified[3]))
                newMatches.add(buildStageMatch("Semi-Final 2", qualified[1], qualified[2]))
            }
            MatchStage.QUALIFIER_1 -> {
                if (qualified.size < 4) {
                    return Result.failure(IllegalStateException("কোয়ালিফায়ারের জন্য অন্তত ৪টি যোগ্য দল প্রয়োজন"))
                }
                newMatches.add(buildStageMatch("Qualifier 1", qualified[0], qualified[1]))
            }
            MatchStage.ELIMINATOR -> {
                if (qualified.size < 4) {
                    return Result.failure(IllegalStateException("এলিমিনেটরের জন্য অন্তত ৪টি যোগ্য দল প্রয়োজন"))
                }
                newMatches.add(buildStageMatch("Eliminator", qualified[2], qualified[3]))
            }
            MatchStage.QUALIFIER_2 -> {
                val q1 = existingMatches.firstOrNull { it.stage == MatchStage.QUALIFIER_1 }
                val elim = existingMatches.firstOrNull { it.stage == MatchStage.ELIMINATOR }
                if (q1 == null || elim == null ||
                    q1.status != MatchStatus.COMPLETED || elim.status != MatchStatus.COMPLETED ||
                    q1.winnerTeamId <= 0L || elim.winnerTeamId <= 0L
                ) {
                    return Result.failure(IllegalStateException("আগে বিজয়ী ঠিক করুন"))
                }
                val q1LoserId = if (q1.winnerTeamId == q1.teamAId) q1.teamBId else q1.teamAId
                val q1Loser = rankedTeams.firstOrNull { it.id == q1LoserId }
                val elimWinner = rankedTeams.firstOrNull { it.id == elim.winnerTeamId }
                if (q1Loser == null || elimWinner == null) {
                    return Result.failure(IllegalStateException("আগে বিজয়ী ঠিক করুন"))
                }
                newMatches.add(buildStageMatch("Qualifier 2", q1Loser, elimWinner))
            }
            MatchStage.FINAL -> {
                val q1Matches = existingMatches.filter { it.stage == MatchStage.QUALIFIER_1 }
                val q2Matches = existingMatches.filter { it.stage == MatchStage.QUALIFIER_2 }
                val semis = existingMatches.filter { it.stage == MatchStage.SEMI_FINAL }

                val finalists: List<TeamEntity> = when {
                    tournament.playoffType == PlayoffType.QUALIFIER_ELIMINATOR || q1Matches.isNotEmpty() -> {
                        val q1 = q1Matches.firstOrNull()
                        val q2 = q2Matches.firstOrNull()
                        if (q1 == null || q2 == null ||
                            q1.status != MatchStatus.COMPLETED || q2.status != MatchStatus.COMPLETED ||
                            q1.winnerTeamId <= 0L || q2.winnerTeamId <= 0L
                        ) {
                            return Result.failure(IllegalStateException("আগে বিজয়ী ঠিক করুন"))
                        }
                        val w1 = rankedTeams.firstOrNull { it.id == q1.winnerTeamId }
                        val w2 = rankedTeams.firstOrNull { it.id == q2.winnerTeamId }
                        if (w1 == null || w2 == null) {
                            return Result.failure(IllegalStateException("আগে বিজয়ী ঠিক করুন"))
                        }
                        listOf(w1, w2)
                    }
                    tournament.playoffType == PlayoffType.SEMI_FINAL || semis.isNotEmpty() -> {
                        val semiWinners = semis
                            .filter { it.status == MatchStatus.COMPLETED && it.winnerTeamId > 0L }
                            .mapNotNull { m -> rankedTeams.firstOrNull { it.id == m.winnerTeamId } }
                        if (semis.size < 2 || semiWinners.size < 2) {
                            return Result.failure(IllegalStateException("আগে বিজয়ী ঠিক করুন"))
                        }
                        semiWinners.take(2)
                    }
                    else -> qualified.take(2)
                }
                newMatches.add(buildStageMatch("Grand Final", finalists[0], finalists[1]))
            }
            else -> Unit
        }

        if (newMatches.isEmpty()) return Result.failure(IllegalStateException("No matches generated."))
        dao.insertMatches(newMatches)
        logAndMarkDirty(tournament.id, actorName, "Generated ${stage.labelEn}", "Added ${newMatches.size} ${stage.labelEn} fixture(s).")
        return Result.success(newMatches.size)
    }

    suspend fun updateMatchPlayersAndInnings(
        matchId: Long,
        currentInnings: Int,
        strikerId: Long,
        nonStrikerId: Long,
        bowlerId: Long,
        status: MatchStatus = MatchStatus.LIVE
    ) {
        val m = dao.getMatchById(matchId) ?: return
        dao.updateMatch(
            m.copy(
                currentInnings = currentInnings,
                activeStrikerId = strikerId,
                activeNonStrikerId = nonStrikerId,
                activeBowlerId = bowlerId,
                status = status,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun swapStrike(matchId: Long) {
        val m = dao.getMatchById(matchId) ?: return
        dao.updateMatch(
            m.copy(
                activeStrikerId = m.activeNonStrikerId,
                activeNonStrikerId = m.activeStrikerId,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun updateBattingFirstTeam(matchId: Long, battingFirstTeamId: Long) {
        val m = dao.getMatchById(matchId) ?: return
        dao.updateMatch(
            m.copy(
                battingFirstTeamId = battingFirstTeamId,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun recordBall(
        matchId: Long,
        strikerId: Long,
        nonStrikerId: Long,
        bowlerId: Long,
        runsOffBat: Int,
        extraRuns: Int,
        extraType: ExtraType,
        isWicket: Boolean,
        wicketType: WicketType,
        dismissedPlayerId: Long
    ) {
        dao.recordBallAndApplyStats(
            matchId = matchId,
            strikerId = strikerId,
            nonStrikerId = nonStrikerId,
            bowlerId = bowlerId,
            runsOffBat = runsOffBat,
            extraRuns = extraRuns,
            extraType = extraType,
            isWicket = isWicket,
            wicketType = wicketType,
            dismissedPlayerId = dismissedPlayerId
        )
    }

    suspend fun undoLastBall(matchId: Long) {
        dao.undoLastBallInMatch(matchId)
    }

    suspend fun editBallEvent(
        ballId: Long,
        newRunsOffBat: Int,
        newExtraRuns: Int,
        newExtraType: ExtraType,
        newIsWicket: Boolean,
        newWicketType: WicketType,
        actorName: String
    ) {
        val old = dao.getBallById(ballId) ?: return
        val match = dao.getMatchById(old.matchId) ?: return
        val newLabel = CricketStatsEngine.formatBallChip(newRunsOffBat, newExtraRuns, newExtraType, newIsWicket)
        dao.updateBallEvent(
            old.copy(
                runsOffBat = newRunsOffBat,
                extraRuns = newExtraRuns,
                extraType = newExtraType,
                isWicket = newIsWicket,
                wicketType = if (newIsWicket) newWicketType else WicketType.NONE,
                isBoundaryFour = newRunsOffBat == 4,
                isBoundarySix = newRunsOffBat == 6,
                summaryLabel = newLabel
            )
        )
        // Recompute innings totals accurately from all ball events in match
        val allBalls = dao.getBallEventsForMatchOnce(match.id)
        val firstBatIsB = match.battingFirstTeamId == match.teamBId
        val i1 = allBalls.filter { it.innings == 1 }
        val i2 = allBalls.filter { it.innings == 2 }
        val teamABallsEvents = if (firstBatIsB) i2 else i1
        val teamBBallsEvents = if (firstBatIsB) i1 else i2
        dao.updateMatch(
            match.copy(
                teamARuns = teamABallsEvents.sumOf { it.runsOffBat + it.extraRuns },
                teamAWickets = teamABallsEvents.count { it.isWicket },
                teamABalls = teamABallsEvents.count { CricketStatsEngine.isLegalDelivery(it.extraType) },
                teamAExtras = teamABallsEvents.sumOf { it.extraRuns },
                teamBRuns = teamBBallsEvents.sumOf { it.runsOffBat + it.extraRuns },
                teamBWickets = teamBBallsEvents.count { it.isWicket },
                teamBBalls = teamBBallsEvents.count { CricketStatsEngine.isLegalDelivery(it.extraType) },
                teamBExtras = teamBBallsEvents.sumOf { it.extraRuns },
                updatedAt = System.currentTimeMillis()
            )
        )
        dao.rebuildTournamentPlayerStats(match.tournamentId)
        if (match.status == MatchStatus.COMPLETED) {
            dao.recalculateTournamentStandings(match.tournamentId)
        }
        logAndMarkDirty(
            match.tournamentId,
            actorName,
            "Edited Ball #${old.sequenceNumber}",
            "Updated ball in Match #${match.matchNumber} to $newLabel."
        )
    }

    suspend fun updateMatchPlayingSquad(
        matchId: Long,
        teamAIds: List<Long>,
        teamBIds: List<Long>,
        actorName: String
    ): Result<Unit> {
        val m = dao.getMatchById(matchId) ?: return Result.failure(IllegalStateException("Match not found"))
        val t = dao.getTournamentById(m.tournamentId)
        val limit = CricketStatsEngine.effectivePlayersPerSideForMatch(m, t)
        val errA = CricketStatsEngine.validatePlayingSelection(teamAIds, limit)
        if (errA != null) return Result.failure(IllegalStateException("${m.teamAName}: $errA"))
        val errB = CricketStatsEngine.validatePlayingSelection(teamBIds, limit)
        if (errB != null) return Result.failure(IllegalStateException("${m.teamBName}: $errB"))

        dao.updateMatch(
            m.copy(
                teamAPlayingIds = CricketStatsEngine.formatPlayingIds(teamAIds),
                teamBPlayingIds = CricketStatsEngine.formatPlayingIds(teamBIds),
                updatedAt = System.currentTimeMillis()
            )
        )
        logAndMarkDirty(
            m.tournamentId,
            actorName,
            "Selected Playing XI",
            "Match #${m.matchNumber}: ${teamAIds.distinct().size} vs ${teamBIds.distinct().size} players (limit $limit)."
        )
        return Result.success(Unit)
    }

    suspend fun finalizeMatch(
        matchId: Long,
        playerOfMatchId: Long,
        playerOfMatchName: String,
        isAbandoned: Boolean,
        actorName: String,
        superOverWinnerTeamId: Long = 0L
    ): Result<Unit> {
        val m = dao.getMatchById(matchId) ?: return Result.failure(IllegalStateException("Match not found"))
        val t = dao.getTournamentById(m.tournamentId)
        val limit = CricketStatsEngine.effectivePlayersPerSideForMatch(m, t)
        val aSel = CricketStatsEngine.parsePlayingIds(m.teamAPlayingIds)
        val bSel = CricketStatsEngine.parsePlayingIds(m.teamBPlayingIds)
        CricketStatsEngine.validatePlayingSelection(aSel, limit)?.let {
            return Result.failure(IllegalStateException("${m.teamAName}: $it"))
        }
        CricketStatsEngine.validatePlayingSelection(bSel, limit)?.let {
            return Result.failure(IllegalStateException("${m.teamBName}: $it"))
        }
        dao.finalizeMatch(matchId, playerOfMatchId, playerOfMatchName, isAbandoned, superOverWinnerTeamId)
        logAndMarkDirty(
            m.tournamentId,
            actorName,
            "Finalized Match #${m.matchNumber}",
            "Completed ${m.teamAName} vs ${m.teamBName}. POM: ${playerOfMatchName.ifBlank { "N/A" }}."
        )
        return Result.success(Unit)
    }

    suspend fun submitManualScore(
        matchId: Long,
        teamARuns: Int,
        teamAWickets: Int,
        teamAOversText: String,
        teamAExtras: Int,
        teamBRuns: Int,
        teamBWickets: Int,
        teamBOversText: String,
        teamBExtras: Int,
        playerStats: List<PlayerMatchStatEntity>,
        playerOfMatchId: Long,
        playerOfMatchName: String,
        customResultText: String,
        actorName: String,
        battingFirstTeamId: Long = 0L,
        teamAPlayingIds: String? = null,
        teamBPlayingIds: String? = null,
        superOverWinnerTeamId: Long = 0L
    ): Result<Unit> {
        val m = dao.getMatchById(matchId) ?: return Result.failure(IllegalStateException("Match not found"))
        val t = dao.getTournamentById(m.tournamentId)
        val limit = CricketStatsEngine.effectivePlayersPerSideForMatch(m, t)
        val aPlayingList = CricketStatsEngine.parsePlayingIds(teamAPlayingIds ?: m.teamAPlayingIds)
        val bPlayingList = CricketStatsEngine.parsePlayingIds(teamBPlayingIds ?: m.teamBPlayingIds)
        if (!CricketStatsEngine.isValidOversInput(teamAOversText) || !CricketStatsEngine.isValidOversInput(teamBOversText)) {
            return Result.failure(IllegalArgumentException("সঠিক ওভার লিখুন (দশমিকের পর ০ থেকে ৫, যেমন ৭.৫)"))
        }
        CricketStatsEngine.validatePlayingSelection(aPlayingList, limit)?.let {
            return Result.failure(IllegalStateException("${m.teamAName}: $it"))
        }
        CricketStatsEngine.validatePlayingSelection(bPlayingList, limit)?.let {
            return Result.failure(IllegalStateException("${m.teamBName}: $it"))
        }

        dao.submitManualMatchScore(
            matchId = matchId,
            teamARuns = teamARuns,
            teamAWickets = teamAWickets,
            teamABalls = CricketStatsEngine.parseOversToBalls(teamAOversText),
            teamAExtras = teamAExtras,
            teamBRuns = teamBRuns,
            teamBWickets = teamBWickets,
            teamBBalls = CricketStatsEngine.parseOversToBalls(teamBOversText),
            teamBExtras = teamBExtras,
            playerStats = playerStats,
            playerOfMatchId = playerOfMatchId,
            playerOfMatchName = playerOfMatchName,
            customResultText = customResultText,
            battingFirstTeamId = battingFirstTeamId,
            teamAPlayingIds = CricketStatsEngine.formatPlayingIds(aPlayingList),
            teamBPlayingIds = CricketStatsEngine.formatPlayingIds(bPlayingList),
            superOverWinnerTeamId = superOverWinnerTeamId
        )
        logAndMarkDirty(
            m.tournamentId,
            actorName,
            "Manual Score Saved",
            "Saved Match #${m.matchNumber} (${m.teamAName} $teamARuns/$teamAWickets vs ${m.teamBName} $teamBRuns/$teamBWickets)."
        )
        return Result.success(Unit)
    }

    suspend fun updateMemberPermissions(
        member: TournamentMemberEntity,
        newRole: UserRole,
        canEditTeams: Boolean,
        canEditSchedule: Boolean,
        canScore: Boolean,
        actorName: String
    ) {
        dao.updateMember(
            member.copy(
                role = newRole,
                canEditTeams = canEditTeams,
                canEditSchedule = canEditSchedule,
                canScore = canScore
            )
        )
        logAndMarkDirty(
            member.tournamentId,
            actorName,
            "Updated Role",
            "Updated ${member.userName} to ${newRole.labelEn}."
        )
    }

    suspend fun removeMember(member: TournamentMemberEntity, actorName: String) {
        dao.deleteMember(member.id)
        logAndMarkDirty(
            member.tournamentId,
            actorName,
            "Revoked Access",
            "Removed ${member.userName} from tournament."
        )
    }

    suspend fun addMemberManually(
        tournamentId: Long,
        name: String,
        email: String,
        role: UserRole,
        actorName: String
    ) {
        val cleanEmail = email.trim().lowercase()
        val existingUser = dao.getUserByEmail(cleanEmail)
        val userId = existingUser?.id ?: dao.insertUser(
            UserEntity(
                fullName = name.trim(),
                email = cleanEmail,
                passwordHash = AuthSecurity.hashPassword(AuthSecurity.generateCode("INV")),
                organization = "Invited Member"
            )
        )
        dao.insertMember(
            TournamentMemberEntity(
                tournamentId = tournamentId,
                userId = userId,
                userName = name.trim(),
                userEmail = cleanEmail,
                role = role,
                canEditTeams = role == UserRole.OWNER || role == UserRole.ADMIN,
                canEditSchedule = role == UserRole.OWNER || role == UserRole.ADMIN,
                canScore = role != UserRole.VIEWER
            )
        )
        logAndMarkDirty(tournamentId, actorName, "Added Member", "Added $name as ${role.labelEn}.")
    }

    suspend fun regenerateCodes(tournament: TournamentEntity, actorName: String) {
        dao.updateTournament(
            tournament.copy(
                editorCode = AuthSecurity.generateCode("ED"),
                viewerCode = AuthSecurity.generateCode("VW"),
                syncDirty = true,
                updatedAt = System.currentTimeMillis()
            )
        )
        logAndMarkDirty(tournament.id, actorName, "Regenerated Access Codes", "Rotated Editor & Viewer join codes.")
    }

    private suspend fun buildTournamentBundle(tournamentId: Long): TournamentBackupBundle? {
        val t = dao.getTournamentById(tournamentId) ?: return null
        val matches = dao.getMatchesByTournamentOnce(tournamentId)
        return TournamentBackupBundle(
            tournament = t,
            teams = dao.getTeamsByTournamentOnce(tournamentId),
            players = dao.getPlayersByTournamentOnce(tournamentId),
            matches = matches,
            balls = matches.flatMap { dao.getBallEventsForMatchOnce(it.id) },
            members = dao.getMembersByTournamentOnce(tournamentId),
            logs = dao.getAuditLogsOnce(tournamentId),
            playerMatchStats = matches.flatMap { dao.getPlayerMatchStatsOnce(it.id) }
        )
    }

    suspend fun exportTournamentBackupJson(tournamentId: Long): Result<String> {
        val bundle = buildTournamentBundle(tournamentId)
            ?: return Result.failure(IllegalStateException("Select a tournament first."))
        return Result.success(BackupSerializer.exportTournamentJson(bundle))
    }

    suspend fun importTournamentBackupJson(rawJson: String, currentUserId: Long): Result<Long> {
        return runCatching {
            val bundle = BackupSerializer.parseTournamentJson(rawJson, currentUserId)
            val newId = dao.replaceTournamentBundle(
                tournament = bundle.tournament,
                teams = bundle.teams,
                players = bundle.players,
                matches = bundle.matches,
                balls = bundle.balls,
                members = bundle.members,
                logs = bundle.logs,
                playerMatchStats = bundle.playerMatchStats
            )
            dao.rebuildTournamentPlayerStats(newId)
            dao.recalculateTournamentStandings(newId)
            preferences.setSelectedTournamentId(newId)
            TournamentSyncWorker.enqueueImmediateSync(appContext)
            newId
        }
    }

    suspend fun triggerSyncNow(): CloudSyncResult {
        TournamentSyncWorker.enqueueImmediateSync(appContext)
        val activeUserId = preferences.activeUserIdFlow.first()
        val activeUser = if (activeUserId > 0L) dao.getUserById(activeUserId) else null
        val resolvedUid = firebaseSyncBridge.currentUid() ?: (activeUser?.email ?: "local-owner")
        val dirty = dao.getAllTournamentsOnce().filter { it.syncDirty }
        val bundles = dirty.mapNotNull { buildTournamentBundle(it.id) }
        val result = firebaseSyncBridge.pushDirtyBundles(bundles, resolvedUid)
        if (result is CloudSyncResult.Synced) {
            dirty.forEach { dao.updateTournament(it.copy(syncDirty = false)) }
            preferences.setLastSyncAt(System.currentTimeMillis())
        }
        return result
    }

    suspend fun recalculateAllTournaments(): Int {
        val count = dao.recalculateAllTournaments()
        val tournaments = dao.getAllTournamentsOnce()
        for (t in tournaments) {
            dao.updateTournament(t.copy(syncDirty = true, updatedAt = System.currentTimeMillis()))
        }
        TournamentSyncWorker.enqueueImmediateSync(appContext)
        return count
    }

    private suspend fun logAndMarkDirty(
        tournamentId: Long,
        actorName: String,
        title: String,
        details: String
    ) {
        dao.insertAuditLog(
            AuditLogEntity(
                tournamentId = tournamentId,
                actorName = actorName,
                actionTitle = title,
                details = details
            )
        )
        dao.getTournamentById(tournamentId)?.let { t ->
            dao.updateTournament(t.copy(syncDirty = true, updatedAt = System.currentTimeMillis()))
        }
        TournamentSyncWorker.enqueueImmediateSync(appContext)
    }
}
