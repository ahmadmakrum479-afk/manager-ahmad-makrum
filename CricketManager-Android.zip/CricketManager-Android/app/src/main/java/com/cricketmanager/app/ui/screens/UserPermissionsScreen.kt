package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.data.local.UserRole
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UserPermissionsScreen(
    tournamentId: Long,
    uiState: CricketUiState,
    viewModel: CricketViewModel,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    val tournament = uiState.tournaments.firstOrNull { it.id == tournamentId } ?: uiState.selectedTournament
    val tId = tournament?.id ?: tournamentId
    val perms = uiState.permissionsFor(tId)
    val members = uiState.allMembers.filter { it.tournamentId == tId }
    val logs = uiState.allAuditLogs.filter { it.tournamentId == tId }
    var showInviteDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { ScreenTopBar(title = strings.permissions, subtitle = tournament?.name, onBack = onBack) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (tournament != null) {
                item {
                    Card(shape = RoundedCornerShape(16.dp)) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Tournament Access Codes", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("Tournament Join Code: ${tournament.tournamentCode}")
                            Text("Viewer Code: ${tournament.viewerCode}")
                            if (perms.canManageRoles) {
                                Text("Editor / Scorer Code: ${tournament.editorCode}", fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { viewModel.regenerateCodes(tournament) }) {
                                        Icon(Icons.Rounded.Refresh, contentDescription = null)
                                        Spacer(Modifier.width(4.dp))
                                        Text("Regenerate Codes")
                                    }
                                    Button(onClick = { showInviteDialog = true }) {
                                        Icon(Icons.Rounded.PersonAdd, contentDescription = null)
                                        Spacer(Modifier.width(4.dp))
                                        Text("Add Member")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Text("Members & Granular Permissions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            items(members, key = { it.id }) { member ->
                Card(shape = RoundedCornerShape(14.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(member.userName, fontWeight = FontWeight.Bold)
                                Text(
                                    "${member.userEmail} · ${member.role.labelEn}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (perms.canManageRoles && member.role != UserRole.OWNER) {
                                IconButton(onClick = { viewModel.removeMember(member) }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = strings.delete)
                                }
                            }
                        }

                        if (perms.canManageRoles && member.role != UserRole.OWNER) {
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(UserRole.ADMIN, UserRole.EDITOR, UserRole.VIEWER).forEach { r ->
                                    FilterChip(
                                        selected = member.role == r,
                                        onClick = {
                                            viewModel.updateMemberRole(
                                                member, r,
                                                canEditTeams = r == UserRole.ADMIN,
                                                canEditSchedule = r == UserRole.ADMIN,
                                                canScore = r != UserRole.VIEWER
                                            )
                                        },
                                        label = { Text(r.labelEn) }
                                    )
                                }
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Can Edit Teams", style = MaterialTheme.typography.bodySmall)
                                Switch(
                                    checked = member.canEditTeams,
                                    onCheckedChange = {
                                        viewModel.updateMemberRole(member, member.role, it, member.canEditSchedule, member.canScore)
                                    }
                                )
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Can Edit Schedule", style = MaterialTheme.typography.bodySmall)
                                Switch(
                                    checked = member.canEditSchedule,
                                    onCheckedChange = {
                                        viewModel.updateMemberRole(member, member.role, member.canEditTeams, it, member.canScore)
                                    }
                                )
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Can Score Matches", style = MaterialTheme.typography.bodySmall)
                                Switch(
                                    checked = member.canScore,
                                    onCheckedChange = {
                                        viewModel.updateMemberRole(member, member.role, member.canEditTeams, member.canEditSchedule, it)
                                    }
                                )
                            }
                        }
                    }
                }
            }

            item {
                Text("Permission & Activity History", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            items(logs.take(30), key = { it.id }) { log ->
                Card(shape = RoundedCornerShape(12.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("${log.actionTitle} · ${log.actorName}", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                        Text(log.details, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    if (showInviteDialog) {
        var name by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var role by remember { mutableStateOf(UserRole.EDITOR) }
        AlertDialog(
            onDismissRequest = { showInviteDialog = false },
            title = { Text("Add Member") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true)
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(UserRole.ADMIN, UserRole.EDITOR, UserRole.VIEWER).forEach { r ->
                            FilterChip(selected = role == r, onClick = { role = r }, label = { Text(r.labelEn) })
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank() && email.isNotBlank()) {
                        viewModel.addMemberManually(tId, name, email, role)
                        showInviteDialog = false
                    }
                }) { Text(strings.save) }
            },
            dismissButton = { TextButton(onClick = { showInviteDialog = false }) { Text(strings.cancel) } }
        )
    }
}
