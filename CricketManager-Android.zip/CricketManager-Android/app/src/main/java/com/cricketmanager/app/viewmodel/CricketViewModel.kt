package com.cricketmanager.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cricketmanager.app.CricketManagerApplication
import com.cricketmanager.app.data.local.ExtraType
import com.cricketmanager.app.data.local.MatchStage
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.PitchType
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.PlayerMatchStatEntity
import com.cricketmanager.app.data.local.PlayerRole
import com.cricketmanager.app.data.local.PlayoffType
import com.cricketmanager.app.data.local.ScoringMode
import com.cricketmanager.app.data.local.TeamEntity
import com.cricketmanager.app.data.local.TieRule
import com.cricketmanager.app.data.local.TournamentEntity
import com.cricketmanager.app.data.local.TournamentFormat
import com.cricketmanager.app.data.local.TournamentMemberEntity
import com.cricketmanager.app.data.local.UserRole
import com.cricketmanager.app.data.local.WicketType
import com.cricketmanager.app.data.repository.TeamDraft
import com.cricketmanager.app.sync.CloudSyncResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CricketViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as CricketManagerApplication
    private val repository = app.repository

    private val readyFlow = MutableStateFlow(false)
    private val statusMessageFlow = MutableStateFlow<String?>(null)
    private val exportedJsonFlow = MutableStateFlow<String?>(null)

    init {
        viewModelScope.launch {
            repository.ensureSeeded(app.database)
            readyFlow.value = true
        }
    }

    private val coreDataFlow = combine(
        repository.usersFlow,
        repository.tournamentsFlow,
        repository.teamsFlow,
        repository.playersFlow,
        repository.matchesFlow
    ) { users, tournaments, teams, players, matches ->
        CoreBundle(users, tournaments, teams, players, matches)
    }

    private val extraDataFlow = combine(
        repository.ballEventsFlow,
        repository.membersFlow,
        repository.auditLogsFlow,
        repository.activeUserIdFlow,
        repository.selectedTournamentIdFlow
    ) { balls, members, logs, activeUserId, selectedTournamentId ->
        ExtraBundle(balls, members, logs, activeUserId, selectedTournamentId)
    }

    private val prefsFlow = combine(
        repository.languageCodeFlow,
        repository.autoSyncFlow,
        repository.lastSyncAtFlow,
        readyFlow,
        statusMessageFlow
    ) { lang, autoSync, lastSyncAt, isReady, statusMsg ->
        PrefsBundle(lang, autoSync, lastSyncAt, isReady, statusMsg)
    }

    val uiState: StateFlow<CricketUiState> = combine(
        coreDataFlow,
        extraDataFlow,
        prefsFlow,
        repository.playerMatchStatsFlow,
        exportedJsonFlow
    ) { core, extra, prefs, playerMatchStats, exportedJson ->
        val activeUser = core.users.firstOrNull { it.id == extra.activeUserId }
        CricketUiState(
            isReady = prefs.isReady,
            activeUser = activeUser,
            languageCode = prefs.lang,
            autoSync = prefs.autoSync,
            lastSyncAt = prefs.lastSyncAt,
            isFirebaseConfigured = repository.isFirebaseConfigured(),
            tournaments = core.tournaments,
            selectedTournamentId = extra.selectedTournamentId,
            allTeams = core.teams,
            allPlayers = core.players,
            allMatches = core.matches,
            allBallEvents = extra.balls,
            allPlayerMatchStats = playerMatchStats,
            allMembers = extra.members,
            allAuditLogs = extra.logs,
            statusMessage = prefs.statusMsg,
            exportedBackupJson = exportedJson
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = CricketUiState()
    )

    fun clearStatusMessage() {
        statusMessageFlow.value = null
    }

    fun clearExportedJson() {
        exportedJsonFlow.value = null
    }

    fun setLanguage(code: String) {
        viewModelScope.launch { repository.setLanguage(code) }
    }

    fun setAutoSync(enabled: Boolean) {
        viewModelScope.launch { repository.setAutoSync(enabled) }
    }

    fun selectTournament(tournamentId: Long) {
        viewModelScope.launch { repository.selectTournament(tournamentId) }
    }

    fun login(email: String, password: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.loginUser(email, password)
                .onSuccess { onSuccess() }
                .onFailure { statusMessageFlow.value = it.message }
        }
    }

    fun signUp(fullName: String, email: String, password: String, organization: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.registerUser(fullName, email, password, organization)
                .onSuccess { onSuccess() }
                .onFailure { statusMessageFlow.value = it.message }
        }
    }

    fun continueAsGuest(onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.continueAsGuestDemo(app.database)
            onSuccess()
        }
    }

    fun logout(onDone: () -> Unit) {
        viewModelScope.launch {
            repository.logout()
            onDone()
        }
    }

    fun joinTournamentByCode(code: String, onJoined: (Long) -> Unit) {
        val user = uiState.value.activeUser ?: return
        viewModelScope.launch {
            repository.joinTournamentByCode(code, user)
                .onSuccess { (t, role) ->
                    statusMessageFlow.value = "Joined ${t.name} (${role.labelEn})"
                    onJoined(t.id)
                }
                .onFailure { statusMessageFlow.value = it.message }
        }
    }

    fun joinAsGuestViewerByCode(code: String, onJoined: () -> Unit) {
        viewModelScope.launch {
            repository.joinAsViewerByCode(code)
                .onSuccess { t ->
                    statusMessageFlow.value = if (uiState.value.languageCode == "BN") {
                        "দর্শক হিসেবে যুক্ত হয়েছেন: ${t.name}"
                    } else {
                        "Joined as Viewer: ${t.name}"
                    }
                    onJoined()
                }
                .onFailure { statusMessageFlow.value = it.message }
        }
    }

    fun createTournament(
        name: String,
        logoEmoji: String,
        organizationName: String,
        pitchType: PitchType,
        scoringMode: ScoringMode,
        format: TournamentFormat,
        oversPerMatch: Int,
        playersPerSide: Int = 11,
        squadSize: Int = 15,
        allOutWickets: Int = 10,
        maxOversPerBowler: Int = 4,
        groupCount: Int,
        rulesSummary: String,
        pointsWin: Int,
        pointsTie: Int,
        pointsLoss: Int,
        pointsAbandoned: Int,
        pointsWalkover: Int = 2,
        tiebreakerOrder: String = "POINTS,WINS,NRR,H2H,NAME",
        tieRule: TieRule = TieRule.SHARE_POINTS,
        matchesPerPair: Int = 1,
        playoffType: PlayoffType = PlayoffType.SEMI_FINAL,
        playoffTeamsCount: Int = 4,
        leaguePlayersPerSide: Int = 0,
        leagueSquadSize: Int = 0,
        leagueOvers: Int = 0,
        playoffPlayersPerSide: Int = 0,
        playoffSquadSize: Int = 0,
        playoffOvers: Int = 0,
        finalPlayersPerSide: Int = 0,
        finalSquadSize: Int = 0,
        finalOvers: Int = 0,
        mottBattingWeight: Double = 1.0,
        mottBowlingWeight: Double = 1.0,
        mottBowlingWicketShare: Double = 0.6,
        mottBowlingEconomyShare: Double = 0.4,
        mottFinalMultiplier: Double = 1.5,
        location: String,
        startDateLabel: String,
        teamDrafts: List<TeamDraft>,
        onCreated: (Long) -> Unit
    ) {
        val user = uiState.value.activeUser ?: return
        viewModelScope.launch {
            val id = repository.createTournamentWithTeams(
                ownerUser = user,
                name = name,
                logoEmoji = logoEmoji,
                organizationName = organizationName,
                pitchType = pitchType,
                scoringMode = scoringMode,
                format = format,
                oversPerMatch = oversPerMatch,
                playersPerSide = playersPerSide,
                squadSize = squadSize,
                allOutWickets = allOutWickets,
                maxOversPerBowler = maxOversPerBowler,
                groupCount = groupCount,
                rulesSummary = rulesSummary,
                pointsWin = pointsWin,
                pointsTie = pointsTie,
                pointsLoss = pointsLoss,
                pointsAbandoned = pointsAbandoned,
                pointsWalkover = pointsWalkover,
                tiebreakerOrder = tiebreakerOrder,
                tieRule = tieRule,
                matchesPerPair = matchesPerPair,
                playoffType = playoffType,
                playoffTeamsCount = playoffTeamsCount,
                leaguePlayersPerSide = leaguePlayersPerSide,
                leagueSquadSize = leagueSquadSize,
                leagueOvers = leagueOvers,
                playoffPlayersPerSide = playoffPlayersPerSide,
                playoffSquadSize = playoffSquadSize,
                playoffOvers = playoffOvers,
                finalPlayersPerSide = finalPlayersPerSide,
                finalSquadSize = finalSquadSize,
                finalOvers = finalOvers,
                mottBattingWeight = mottBattingWeight,
                mottBowlingWeight = mottBowlingWeight,
                mottBowlingWicketShare = mottBowlingWicketShare,
                mottBowlingEconomyShare = mottBowlingEconomyShare,
                mottFinalMultiplier = mottFinalMultiplier,
                location = location,
                startDateLabel = startDateLabel,
                teamDrafts = teamDrafts
            )
            statusMessageFlow.value = "Created $name"
            onCreated(id)
        }
    }

    fun updateTournamentRules(updated: TournamentEntity) {
        val actor = uiState.value.activeUser?.fullName ?: "Organizer"
        viewModelScope.launch {
            repository.updateTournamentRules(updated, actor)
            statusMessageFlow.value = if (uiState.value.languageCode == "BN") {
                "টুর্নামেন্টের নিয়ম সংরক্ষিত হয়েছে"
            } else {
                "Tournament rules updated"
            }
        }
    }

    fun markMatchWalkover(matchId: Long, winnerTeamId: Long) {
        val actor = uiState.value.activeUser?.fullName ?: "Organizer"
        viewModelScope.launch {
            repository.markMatchWalkover(matchId, winnerTeamId, actor)
            statusMessageFlow.value = "Walkover recorded"
        }
    }

    fun addTeam(
        tournamentId: Long,
        name: String,
        shortCode: String,
        logoEmoji: String,
        captainName: String,
        groupName: String,
        homeGround: String
    ) {
        val actor = uiState.value.activeUser?.fullName ?: "Organizer"
        viewModelScope.launch {
            repository.addTeam(tournamentId, name, shortCode, logoEmoji, captainName, groupName, homeGround, actor)
            statusMessageFlow.value = "Team added: $name"
        }
    }

    fun deleteTeam(team: TeamEntity) {
        val actor = uiState.value.activeUser?.fullName ?: "Organizer"
        viewModelScope.launch { repository.deleteTeam(team, actor) }
    }

    fun addPlayer(
        tournamentId: Long,
        teamId: Long,
        name: String,
        jerseyNumber: Int,
        role: PlayerRole,
        battingStyle: String,
        bowlingStyle: String,
        photoEmoji: String,
        isCaptain: Boolean
    ) {
        val actor = uiState.value.activeUser?.fullName ?: "Organizer"
        viewModelScope.launch {
            repository.addPlayer(
                tournamentId, teamId, name, jerseyNumber, role, battingStyle, bowlingStyle, photoEmoji, isCaptain, actor
            )
            statusMessageFlow.value = "Player added: $name"
        }
    }

    fun deletePlayer(player: PlayerEntity) {
        val actor = uiState.value.activeUser?.fullName ?: "Organizer"
        viewModelScope.launch { repository.deletePlayer(player, actor) }
    }

    fun updatePlayerStatsDirect(
        player: PlayerEntity,
        matchesPlayed: Int,
        runsScored: Int,
        ballsFaced: Int,
        fours: Int,
        sixes: Int,
        highestScore: Int,
        wicketsTaken: Int,
        runsConceded: Int,
        oversBowledText: String
    ) {
        val actor = uiState.value.activeUser?.fullName ?: "Organizer"
        viewModelScope.launch {
            repository.updatePlayerStatsDirect(
                player, matchesPlayed, runsScored, ballsFaced, fours, sixes, highestScore,
                wicketsTaken, runsConceded, oversBowledText, actor
            )
            statusMessageFlow.value = "Updated stats for ${player.name}"
        }
    }

    fun createMatch(
        tournament: TournamentEntity,
        teamA: TeamEntity,
        teamB: TeamEntity,
        stage: MatchStage,
        groupName: String,
        venue: String,
        scheduledDate: String,
        scheduledTime: String,
        oversLimit: Int,
        scoringMode: ScoringMode
    ) {
        val actor = uiState.value.activeUser?.fullName ?: "Organizer"
        viewModelScope.launch {
            repository.createMatch(
                tournament, teamA, teamB, stage, groupName, venue, scheduledDate, scheduledTime, oversLimit, scoringMode, actor
            )
            statusMessageFlow.value = "Match scheduled: ${teamA.shortCode} vs ${teamB.shortCode}"
        }
    }

    fun generateStage(tournament: TournamentEntity, stage: MatchStage) {
        val actor = uiState.value.activeUser?.fullName ?: "Organizer"
        viewModelScope.launch {
            repository.generateKnockoutStage(tournament, stage, actor)
                .onSuccess { count -> statusMessageFlow.value = "Generated $count ${stage.labelEn} match(es)" }
                .onFailure { statusMessageFlow.value = it.message }
        }
    }

    fun updateActivePlayers(
        matchId: Long,
        innings: Int,
        strikerId: Long,
        nonStrikerId: Long,
        bowlerId: Long,
        status: MatchStatus = MatchStatus.LIVE
    ) {
        viewModelScope.launch {
            repository.updateMatchPlayersAndInnings(matchId, innings, strikerId, nonStrikerId, bowlerId, status)
        }
    }

    fun swapStrike(matchId: Long) {
        viewModelScope.launch { repository.swapStrike(matchId) }
    }

    fun updateBattingFirstTeam(matchId: Long, battingFirstTeamId: Long) {
        viewModelScope.launch { repository.updateBattingFirstTeam(matchId, battingFirstTeamId) }
    }

    fun recordBall(
        matchId: Long,
        strikerId: Long,
        nonStrikerId: Long,
        bowlerId: Long,
        runsOffBat: Int,
        extraRuns: Int,
        extraType: ExtraType,
        isWicket: Boolean,
        wicketType: WicketType,
        dismissedPlayerId: Long
    ) {
        viewModelScope.launch {
            repository.recordBall(
                matchId, strikerId, nonStrikerId, bowlerId, runsOffBat, extraRuns, extraType, isWicket, wicketType, dismissedPlayerId
            )
        }
    }

    fun undoLastBall(matchId: Long) {
        viewModelScope.launch {
            repository.undoLastBall(matchId)
            statusMessageFlow.value = "Last ball undone"
        }
    }

    fun editBallEvent(
        ballId: Long,
        newRunsOffBat: Int,
        newExtraRuns: Int,
        newExtraType: ExtraType,
        newIsWicket: Boolean,
        newWicketType: WicketType
    ) {
        val actor = uiState.value.activeUser?.fullName ?: "Scorer"
        viewModelScope.launch {
            repository.editBallEvent(ballId, newRunsOffBat, newExtraRuns, newExtraType, newIsWicket, newWicketType, actor)
            statusMessageFlow.value = "Ball updated"
        }
    }

    fun saveMatchPlayingSquad(
        matchId: Long,
        teamAIds: List<Long>,
        teamBIds: List<Long>,
        onError: (String) -> Unit = {},
        onSaved: () -> Unit = {}
    ) {
        val actor = uiState.value.activeUser?.fullName ?: "Scorer"
        viewModelScope.launch {
            repository.updateMatchPlayingSquad(matchId, teamAIds, teamBIds, actor)
                .onSuccess {
                    statusMessageFlow.value = if (uiState.value.languageCode == "BN") {
                        "ম্যাচের একাদশ সংরক্ষিত হয়েছে"
                    } else {
                        "Match playing squad saved"
                    }
                    onSaved()
                }
                .onFailure {
                    val msg = it.message ?: "খেলোয়াড় বাছাই সীমা ছাড়িয়েছে"
                    statusMessageFlow.value = msg
                    onError(msg)
                }
        }
    }

    fun finalizeMatch(
        matchId: Long,
        pomId: Long,
        pomName: String,
        isAbandoned: Boolean,
        superOverWinnerTeamId: Long = 0L,
        onError: (String) -> Unit = {},
        onSuccess: () -> Unit = {}
    ) {
        val actor = uiState.value.activeUser?.fullName ?: "Scorer"
        viewModelScope.launch {
            repository.finalizeMatch(matchId, pomId, pomName, isAbandoned, actor, superOverWinnerTeamId)
                .onSuccess {
                    statusMessageFlow.value = "Match finalized & NRR updated"
                    onSuccess()
                }
                .onFailure {
                    val msg = it.message ?: "ম্যাচ শেষ করা যায়নি"
                    statusMessageFlow.value = msg
                    onError(msg)
                }
        }
    }

    fun submitManualScore(
        matchId: Long,
        teamARuns: Int,
        teamAWickets: Int,
        teamAOversText: String,
        teamAExtras: Int,
        teamBRuns: Int,
        teamBWickets: Int,
        teamBOversText: String,
        teamBExtras: Int,
        playerStats: List<PlayerMatchStatEntity>,
        pomId: Long,
        pomName: String,
        customResultText: String,
        battingFirstTeamId: Long = 0L,
        teamAPlayingIds: String? = null,
        teamBPlayingIds: String? = null,
        superOverWinnerTeamId: Long = 0L,
        onError: (String) -> Unit = {},
        onSaved: () -> Unit
    ) {
        val actor = uiState.value.activeUser?.fullName ?: "Scorer"
        viewModelScope.launch {
            repository.submitManualScore(
                matchId = matchId,
                teamARuns = teamARuns,
                teamAWickets = teamAWickets,
                teamAOversText = teamAOversText,
                teamAExtras = teamAExtras,
                teamBRuns = teamBRuns,
                teamBWickets = teamBWickets,
                teamBOversText = teamBOversText,
                teamBExtras = teamBExtras,
                playerStats = playerStats,
                playerOfMatchId = pomId,
                playerOfMatchName = pomName,
                customResultText = customResultText,
                actorName = actor,
                battingFirstTeamId = battingFirstTeamId,
                teamAPlayingIds = teamAPlayingIds,
                teamBPlayingIds = teamBPlayingIds,
                superOverWinnerTeamId = superOverWinnerTeamId
            )
                .onSuccess {
                    statusMessageFlow.value = "Manual scorecard saved & NRR updated"
                    onSaved()
                }
                .onFailure {
                    val msg = it.message ?: "স্কোর সেভ করা যায়নি"
                    statusMessageFlow.value = msg
                    onError(msg)
                }
        }
    }

    fun updateMemberRole(
        member: TournamentMemberEntity,
        role: UserRole,
        canEditTeams: Boolean,
        canEditSchedule: Boolean,
        canScore: Boolean
    ) {
        val actor = uiState.value.activeUser?.fullName ?: "Owner"
        viewModelScope.launch {
            repository.updateMemberPermissions(member, role, canEditTeams, canEditSchedule, canScore, actor)
            statusMessageFlow.value = "Permissions updated"
        }
    }

    fun removeMember(member: TournamentMemberEntity) {
        val actor = uiState.value.activeUser?.fullName ?: "Owner"
        viewModelScope.launch { repository.removeMember(member, actor) }
    }

    fun addMemberManually(tournamentId: Long, name: String, email: String, role: UserRole) {
        val actor = uiState.value.activeUser?.fullName ?: "Owner"
        viewModelScope.launch {
            repository.addMemberManually(tournamentId, name, email, role, actor)
            statusMessageFlow.value = "Member added: $name"
        }
    }

    fun regenerateCodes(tournament: TournamentEntity) {
        val actor = uiState.value.activeUser?.fullName ?: "Owner"
        viewModelScope.launch {
            repository.regenerateCodes(tournament, actor)
            statusMessageFlow.value = "Access codes regenerated"
        }
    }

    fun exportBackup(tournamentId: Long) {
        viewModelScope.launch {
            repository.exportTournamentBackupJson(tournamentId)
                .onSuccess { json -> exportedJsonFlow.value = json }
                .onFailure { statusMessageFlow.value = it.message }
        }
    }

    fun importBackup(rawJson: String) {
        val userId = uiState.value.activeUser?.id ?: 1L
        viewModelScope.launch {
            repository.importTournamentBackupJson(rawJson, userId)
                .onSuccess { statusMessageFlow.value = "Backup restored into local database" }
                .onFailure { statusMessageFlow.value = "Invalid backup JSON: ${it.message}" }
        }
    }

    fun syncNow() {
        viewModelScope.launch {
            when (val res = repository.triggerSyncNow()) {
                is CloudSyncResult.Synced ->
                    statusMessageFlow.value = "Synced ${res.syncedCount} tournament(s) to Firestore"
                CloudSyncResult.NotConfigured ->
                    statusMessageFlow.value = "Offline SQLite active. Add google-services.json for Firebase cloud sync."
                is CloudSyncResult.Error ->
                    statusMessageFlow.value = "Sync failed: ${res.message}"
            }
        }
    }

    fun recalculateAllTournaments() {
        viewModelScope.launch {
            val count = repository.recalculateAllTournaments()
            statusMessageFlow.value = if (uiState.value.languageCode == "BN") {
                "$count টি টুর্নামেন্টের সব হিসাব নতুন করে সম্পন্ন হয়েছে"
            } else {
                "Recalculated standings & player stats for $count tournament(s)"
            }
        }
    }

    private data class CoreBundle(
        val users: List<com.cricketmanager.app.data.local.UserEntity>,
        val tournaments: List<TournamentEntity>,
        val teams: List<TeamEntity>,
        val players: List<PlayerEntity>,
        val matches: List<com.cricketmanager.app.data.local.MatchEntity>
    )

    private data class ExtraBundle(
        val balls: List<com.cricketmanager.app.data.local.BallEventEntity>,
        val members: List<TournamentMemberEntity>,
        val logs: List<com.cricketmanager.app.data.local.AuditLogEntity>,
        val activeUserId: Long,
        val selectedTournamentId: Long
    )

    private data class PrefsBundle(
        val lang: String,
        val autoSync: Boolean,
        val lastSyncAt: Long,
        val isReady: Boolean,
        val statusMsg: String?
    )
}
