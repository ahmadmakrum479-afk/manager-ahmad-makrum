package com.cricketmanager.app.ui.theme

import androidx.compose.ui.graphics.Color

val PitchEmerald = Color(0xFF047857)
val PitchEmeraldDark = Color(0xFF064E3B)
val PitchEmeraldSoft = Color(0xFFD1FAE5)

val BoundaryCrimson = Color(0xFFDC2626)
val BoundaryCrimsonSoft = Color(0xFFFEE2E2)

val GoldAccent = Color(0xFFD97706)
val GoldAccentSoft = Color(0xFFFEF3C7)

val NavyInk = Color(0xFF0F172A)
val SlateInk = Color(0xFF334155)
val MutedInk = Color(0xFF64748B)
val StadiumOffWhite = Color(0xFFF8FAFC)
val CardWhite = Color(0xFFFFFFFF)
val DividerGrey = Color(0xFFE2E8F0)

val DarkStadiumBg = Color(0xFF0B1120)
val DarkCardBg = Color(0xFF111827)
